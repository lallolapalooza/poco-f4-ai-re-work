{
  "status": "complete",
  "blobs_decoded": 16,
  "runner": "reimpl/eai_run.py (numpy EAI2 interpreter); reimpl/run_vad.py runs the DNN VAD end to end, exit 0",
  "blockers": [
    "Keyword stage (1st/1.5 stage): framer + gru semantics not numerically reproduced. framer_forward (vaddr 0x1136e0) is a ring buffer driven by layer+0x74/0x7c; gru_forward_vanilla_step (vaddr 0x1447c) is a fused variant (one 3H gemm, sigmoid over 2H, reset-scaled tanh, final h = A*z + B - B*z) whose operand wiring and layer+0x78 mode switch are unresolved - a search over standard GRU families against the native T14 state of 63ff0ae5_en-US_001_198088 leaves a 6.7e-02 residual. Ghidra shows the 10-argument call for a 14-parameter function, so args must come from the assembly at 0x14ca0/0x14e6c, not the pseudocode. Unverified ops are gated behind allow_unverified=True; nothing fabricated.",
    "4 of 16 blobs cannot run under the shipped floating runtime: 001_58312 and 001_968 (builder 12.2 vs runtime 4.3), 038_1224 (target/enpu v4, quantised payloads), 038_43208 (header +0x0c bit2 clear = fixed-point). Each refusal is predicted from the header and matches the library log.",
    "general_UV_015 (user verification, 449 tensors / 252 layers) parses and loads but needs conv/batchnorm/globalavgpool/div/reduce semantics, which are only transcribed - same verification gap as the keyword stage.",
    "VAD input semantics: the model takes 1x160 float32 per frame from the libqvavad CAPI_v2 front-end; that 160-dim feature definition is not decoded (the 80-bin mel in pipeline.py belongs to libqvasml/udk7). run_vad.py therefore feeds the oracle frame or a documented synthetic one; the model itself is exact.",
    "super* fused ops (superconv/supergemm/superadd/supersub/superdeconv) only occur in 038_1224 which the runtime refuses; quantize/squeeze/unsqueeze only in the two builder-12.2 blobs."
  ],
  "files": [
    "reports/qcom_voiceactivation/reimpl/eai_loader.py",
    "reports/qcom_voiceactivation/reimpl/eai_run.py",
    "reports/qcom_voiceactivation/reimpl/run_vad.py",
    "reports/qcom_voiceactivation/reimpl/verify_eai.py",
    "reports/qcom_voiceactivation/reimpl/verify.txt",
    "reports/qcom_voiceactivation/reimpl/GAP_CLOSURE.md",
    "reports/qcom_voiceactivation/reimpl/coverage_fragment.json",
    "reports/qcom_voiceactivation/reimpl/README.md",
    "reports/qcom_voiceactivation/reimpl/pipeline.py",
    "reports/qcom_voiceactivation/ir/eai_parsed.json",
    "reports/qcom_voiceactivation/evidence/harness/eai_host.c",
    "reports/qcom_voiceactivation/evidence/harness/run_harness.sh",
    "reports/qcom_voiceactivation/evidence/native_dumps/",
    "reports/qcom_voiceactivation/evidence/ghidra/eai_parse.c",
    "reports/qcom_voiceactivation/evidence/ghidra/eai_tensor_ops.c",
    "reports/qcom_voiceactivation/evidence/ghidra/eai_rnn.c",
    "reports/qcom_voiceactivation/evidence/ghidra/libeai_floating_symtab.txt"
  ],
  "notes": "FORMAT CLOSED. libeai_floating.so ships a .gnu_debugdata xz-compressed ELF with a 425-symbol .symtab; merging it via objcopy before Ghidra named the whole loader chain and every op loader/forward. Layout documented byte-level in reimpl/GAP_CLOSURE.md: header 0x28B (magic 'eai2', u16 major/minor 2.2, compiler bytes @+8/+0x0a, flags @+0x0c bit2=float, size @+0x10, scratch @+0x14, persistent @+0x18, n_sections @+0x1c, target/enpu byte @+0x21); 16B section entries {type,size,offset} with types 0 misc / 1 tensors / 2 constants / 3 unrecognised / 4 layers / 5 layer_io / 6 extra; 0x50B tensor descriptors (flags @+8 bit0=constant bit2=activation bit7/30=persistent, ndim @+0x0c, dims-form tag @+0x14 = 43210/34210/23410/21430/23140/823410, dims[5] @+0x18, pool offset @+0x2c with 0xffffffff=none, byte size @+0x38, dtype @+0x3c low nibble=element size); tensor groups 0=constants into section 2, 1=scratch (overlapping liveness plan), 2=persistent; variable-size layer records {op_id, size, flags(bit8 offline params, bit9 runtime skip), group u16 @+0x0c, subtype u8 @+0x0e, params from +0x10}; u16 layer-I/O table [n_in, n_out, in_ids, out_ids] with 0xffff=unused. Op enum from so_op_intf_load2 (0x00 conv ... 0x46 supermaxpool). NATIVE ORACLE: evidence/harness/eai_host.c mmaps the DSO and applies RELR/RELA/JUMP_SLOT itself (dlopen fails on pre-standard DT_RELR tags 0x6fffe000/1/3 and LIBC symbol versions) and drives eai_init_ex/eai_preapply/eai_set_property(0)/eai_apply/eai_execute under qemu-aarch64; 12/16 blobs load. VERIFICATION: verify.txt = 5065 checks, 0 failures - parse matches the library's own parse field-by-field (sections, all tensor descriptors, all layer records, I/O slots) on all 16 blobs, the 4 refusals are predicted from the header, and the DNN VAD (speech_float, 9 layers gemm/relu/no_op x3/lstm/softmax) matches the native interpreter to 6e-08 with a bit-identical softmax (p(speech)=0.015254 on the oracle frame). LSTM gate order re-derived from the dump: i=sig(pre[0:H]), o=sig(pre[H:2H]), f=sig(pre[2H:3H]), g=tanh(pre[3H:4H]), c=f*c_prev+i*g, h=o*tanh(c), both bias inputs summed; h0/c0 unused so the layer is stateless per frame. VERIFIED_OPS = {no_op, relu, gemm, softmax, lstm}; gemm shapes come from the descriptors: out[N,M] = X[N,K] @ W[M,K]^T + b[M] with W = the constant-flagged input."
}