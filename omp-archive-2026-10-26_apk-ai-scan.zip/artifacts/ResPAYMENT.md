{
  "status": "complete",
  "model_format": "LIBSVM text model (svm_save_model), c_svc + rbf. The 'sm_type' magic (73766d5f74797065) is just the ASCII header 'svm_type' — nothing is opaque or encrypted. Digital_OCR_svm_9.model: nr_class=10, total_sv=1076, gamma=2.0, nSV=[115,89,76,128,87,134,152,47,137,111], labels 0-9. Digital_OCR_svm_2.model: nr_class=2, total_sv=545, gamma=0.5, nSV=[295,250], labels 0/1. Both parsed to dense sv[1076,144]/coef[1076,9] and sv[545,144]/coef[545,1].",
  "parsed": true,
  "pipeline": [
    "Java: com.mibi.ocr.entry.DigitOcrEntry -> CaptureActivity/CaptureFragment (plugin bundle 'ocr', Bundle-SymbolicName com.mibi.ocr)",
    "a.b.a.c DigitOCRManager: camera + mask rect -> preview coords + rotation; a.b.a.f RecognizeController runs a.b.a.d on a HandlerThread",
    "a.b.a.d: NV21 Y -> ARGB int((Y&0xff)*0x10101|0xFF000000), rotate, crop, copyPixelsToBuffer (RGBA_8888)",
    "XiaoMIDigitOCR (System.loadLibrary digit_ocr): nativeBeginProcess(j, svm9, svm2), nativeSetImage(bb,w,h,4), nativeRecogDigit -> int[]",
    "JNI thin wrappers -> MainOCR::beginProcess/setImage/process_OneImg; CDigitalOCR::LoadModel uses svm_load_cvt_model (two svm_model*: 10-class at this+0x110, binary at +0x118)",
    "DigitSegment::SegDigitInGrayImg: rgbToGray(fmt) -> adaptiveThreshold -> FindDigitConnectedReigon -> FindDigitTargetRect(aspect 1.0..3.5) -> RANSAC line / CorrectBiasAngle -> SetDigitMatVector -> 20x32 grayscale patches",
    "CFEATURE_HOG::ExtractGradientOrientation(patch,20,32): binarize >80; gx=p[y][x]-p[y][x-1] (x>=1), gy=p[y][x]-p[y-1][x] (y>=1); ang=atan2(gy,gx)*180/pi+180 mod 360; bin=(x/5+(y/8)*4)*9+int(ang/40); hist/40 -> 144 float32",
    "CDigitalOCR::Predict: svm_predict_probability(model_9) -> argmax digit, OCR_STR{uint32 digit; uint32 conf=int(prob*100)}, plus 2nd/3rd candidate while prob>0.1",
    "CDigitalOCR::PredictNegPos: svm_predict_probability(model_2) -> prob[0]>0.5 gate, called from MainOCR::trimBadDigit (0x2939c, 0x29444)",
    "MainOCR assembles the digit string; default digit-count range 15..19 (bank PAN); getRecognitionResultString -> Java nativegetDigitResultString"
  ],
  "jax_status": "verified: reimpl/pipeline.py exits 0. Real shipped weights (nothing random-initialised). HOG features bit-exact vs the vendor (max|diff| 0.0); 45 decision values max|diff| 6.7e-08; probabilities max|diff| 4.7e-11 (numpy and JAX float64) on 6 vectors; JAX classifies the vendor's own 4 normalised 20x32 patches as '1234', matching the vendor MainOCR digit_array 1 2 3 4 on a synthetic card-number image. 28x28 and 32x32 inputs accepted via nearest-neighbour resample to 20x32.",
  "unknowns": [
    "adaptiveThreshold is a non-exported local function: window size, offset C and mean-vs-Gaussian weighting not recovered",
    "rgbToGray coefficients per format 1..4 not recovered (Java always passes 4)",
    "DigitSegment constants beyond the (1.0, 3.5) aspect bounds and the DP/projection-histogram split logic (FindSegPointFromHistogram/FindSegPointDP)",
    "svm_load_cvt_model's internal pre-conversion not decoded (verified numerically identical to svm_load_model)",
    "Semantics of the binary model label 0 vs 1 (which side means 'is a digit') not provable from the binary",
    "Segmentation stage not reimplemented in JAX — only the classifier stage (where all learned parameters live) is; its 20x32 patch input contract is enforced and verified"
  ],
  "notes": "Deliverables in $WS/reports/miui_paymentservice: report.md (9 sections), findings.json (validated: evidence/validate_findings.py prints VALID), sources/ (+index.md, 12 com.mibi.ocr/JNI classes + 12 a.b.a.* classes), native/ (elf_info json, 64-function Ghidra pseudocode, HOG/Predict disassembly, README, harness/), models/ (2 shipped models), ir/ (parsed SVM IR + op sequence), reimpl/ (lsvm.py, hog.py, jax_model.py, pipeline.py, README.md, verify.txt exit 0), evidence/ (cmds, hashes, 6 HOG vectors with native features/probs/dec values, vendor 20x32 patches, validator). Directory is 5.7 MB total; native/ is 1.3 MB; all qemu core dumps and crash artifacts deleted and no further aarch64 execution is needed — every reference number is already captured on disk. Note for the coordinator: qemu-aarch64 did work here (cross-gcc + a 20-line bionic shim: __android_log_print/__errno/_ctype_/__sF + stdio interposition, plus two benign .dynamic patches on a COPY so glibc skips bionic's NULL init_array slots); that is what produced the vendor-side reference data, and native/harness/build.sh is kept only for optional reproduction."
}