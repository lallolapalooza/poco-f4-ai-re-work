{
  "status": "complete",
  "pipeline_file": "reports/mtb_modemtestbox/PIPELINE.md",
  "pipelines": [
    "ai_weak_signal_forecast: secret code *#*#24744625#*#* (android_secret_code host 24744625) or explicit GAME_STATUS broadcast or direct bind of exported AiWeakSignalForecastService -> onStartCommand/onBind -> initService (cloud-switch check, OemHookAgent.getHook(), [1,400,1]/[1,2] alloc, TFLite Interpreter from mmap'd asset, 10-thread scheduler) -> 10 Hz pull getLteMeasInfo/getNr5gMeasInfo -> ByteBuffer parse (LTE RSRP@57/RSRQ@61/SINR@65/PCI@69, >=73 B; NR RSRQ@17/PCI@37/RSRP@41/SINR@45, >=49 B) -> 100-entry ArrayDeque -> 1 Hz medianFilter(w=5) -> float32[1,400,1] -> TFLite (p[1]<0.5=WEAK else STRONG) -> Log.d 'forecastRes' + implicit FORECAST_RES broadcast (only when started via GAME_STATUS) + IAiWeakSignal.getForecastRes binder"
  ],
  "gaps_closed": [
    "Android entry: exact manifest coordinates for the service (exported=true, no permission, sharedUserId android.uid.system) and receiver (exported=true, no permission, SECRET_CODE hosts); secret-code host 24744625 -> MtbBroadcastReceiver.onReceive:224 -> AiWeakSignalForecastService.onAiSignalBcHandle:270 (static-boolean toggle); GAME_STATUS handler at :88/:285; documented that the manifest declares GAME_START/GAME_EXIT but not GAME_STATUS, so that action only works as an explicit broadcast",
    "Measurement source: confirmed pull (not callbacks) via OemHookAgent.getHook() (null until qcrilhook onQcRilHookReady), reflective call into system_ext/framework/mirilhook.jar com.xiaomi.mirilhook.MiRilHook -> HydraDataManager; exact ByteBuffer read offsets for LTE and NR; range validation; null/partial buffer handling (previous values silently re-appended); buffer ownership (fresh buffer per call, consumed once, never rewound); ArrayDeque depth 100 drop-oldest shared unsynchronised across two tasks of a newScheduledThreadPool(10); timestamps are HH:mm:ss.mmm strings never used by the pipeline",
    "Output path: p[1]<0.5 -> WEAK/STRONG, no smoothing/formatting/score exposure; sentinel 'NOT Ready'; implicit unprotected FORECAST_RES broadcast at 1 Hz (gated by isfrombroadcast, which is never set on the bind path); IAiWeakSignal.getForecastRes ignores its argument and enforces no caller permission; action literal occurs exactly once in the DEX string table -> no in-APK consumer",
    "Lifecycle: initService/onStartCommand/onBind/onDestroy ordering, no wake lock / no foreground service / no AlarmManager, executor shutdown-only cancellation, stopSelf() without return, START_STICKY null-intent NPE path that can leak a second executor, screen-off suspend + fixed-rate catch-up burst",
    "Failure/fallback matrix: hook null -> sampler cancellation, model-load failure -> mTFLite null -> forecaster cancellation, BufferUnderflow, unsupported RAT, stale retention; no fallback anywhere",
    "Resolved prior unknowns: ModemUtils.PROP_SAR_LOG_SWITCH_OPEN == \"true\" / CLOSE == \"false\"; stale/partial buffer behaviour now traced",
    "Added PIPELINE.md (9 template sections), report.md §9 + evidence-index rows, findings.json data_pipelines entry, evidence/manifest.xml + manifest_dump.py + consumer_refs.jsonl + validate_findings.py/v2, sources for OemHookAgent/ModemUtils/MiRilHook"
  ],
  "remaining_unknowns": [
    "Hydra/mirilhook field semantics and units behind the LTE (>=73 B) and NR (>=49 B) buffers",
    "Which external component consumes com.xiaomi.mtb.aisignal.FORECAST_RES (no in-APK receiver or UI)",
    "Training corpus/date of 0.3_new_0410_less and whether the fixed 0.5 threshold was calibrated",
    "Whether android.provider.Telephony.SECRET_CODE is a protected broadcast on this ROM (inferred only)",
    "Whether the int argument to getLteMeasInfo/getNr5gMeasInfo is a phone id or slot index"
  ],
  "notes": "Verification run: evidence/validate_findings.py -> VALID (required keys, types, enums, data_pipelines structure; jsonschema is not installed in the venv, so the checker implements the schema's required/enum/type rules). JSON parses. No native code exists in this APK, so native/ was left unchanged. New files only under reports/mtb_modemtestbox; prior report content preserved (one 'Unknown' paragraph annotated, not deleted). jadx single-class used for 3 in-APK classes + 1 class from system_ext/framework/mirilhook.jar (outside the APK, cited as context)."
}