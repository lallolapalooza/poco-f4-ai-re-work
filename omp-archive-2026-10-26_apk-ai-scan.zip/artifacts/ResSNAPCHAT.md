{
  "status": "complete",
  "ships_dnn": false,
  "components": [
    "Looksery Haar face detection (assets/looksery/core/HaarCascades/haarcascade_frontalface_alt2.xml; 20 stages / 1047 depth-2 trees / 4535 rects) via libcamplat LS::FaceDetectorStage",
    "Looksery ERT landmark tracking (LiteTrackingData_ert.lns: LZC v1 + zstd container with Tracking.xml and 5 packed ERT regressors: face 68, eyes, denoise, Candide, Candide perspective)",
    "Looksery ORB natural-feature tracking (2 protobuf vocabulary trees, 1+20+400 nodes, 32-byte centroids)",
    "Looksery Scenarium AR deformation + GLES (facestretchLiquify.glsl, inpainting_gpu.glsl, 275 GLSL, triangulation.txt 118 tris)",
    "Snap PreviewCV classical filters in libcamplat (SnapCut/PortraitFilter/SkyFilter/MomentFilter, ManyTargetTracker; 677 JNI exports)",
    "Snap AI Factory / Cameo (app.aifactory.*: FaceNeutrality, FSFaceSegmentation, LandmarksExtractor, F2F) with MACE backend string, AES ModelCrypto and downloaded .dnn.enc models (absent)",
    "Google ML Kit barcode / GmsCore face detection (registrars + parcels only; external Play-services contract)",
    "Cloud/server: Memories face clustering, libclient learned_search ModelCoordinator, voiceml intents/keywords"
  ],
  "reimpl_status": "verified: reimpl/verify.py -> 11/11 checks passed, exit 0, verify.txt written (JAX Haar cascade with real weights; JAX FAST-9/BRIEF-256 tracking with real ORB tree; exact liquify + triangle-mesh warp; JAX-vs-scalar max diff 3.4e-08; detection box exact; noise rejected; ORB translation exactly (7,-5))",
  "unknowns": [
    "Proprietary ERT regressor binary layout (tag byte 0x53, mixed int32/IEEE-754 doubles) not decoded -> landmark regression is architecture-only",
    "Candide-3 files (candide3reduce/14AU) encrypted/obfuscated (5,612-byte shared prefix); plaintext unavailable",
    "Whether bloops .dnn.enc models run on MACE or TNN (manifest tnn_shared_lib=libtnn.so, ctor string 'MACE'); no runtime library ships",
    "Whether bundled lenses exercise libcamplat's dlopen TFLite path; no TFLite model ships",
    "OpenCV 5 xobjdetect rounds scaled Haar rects differently from the classic calc_offsets path used by libcamplat (classic convention implemented; verified at base scale)",
    "Remote lens assets (.crypt.glsl, LSRemoteAssetsWrapper) encrypted with keys not in the APK"
  ],
  "notes": "Report at reports/snapchat/report.md; findings.json validates against SCHEMA.json (8 features, 8 models, 7 unknowns); dirs sources/native/models/ir/reimpl/evidence populated; APK sha256 70147a34fd974522a43a142ad1a5c81a0698b74663a3933e88bde30846a50238. DNN verdict evidence: apk_inventory ai_models=0/ai_libs=0; 0 TFL3 occurrences across all 6,869 zip entries; no .tflite/.onnx/.dlc/.dnn/.enc member; no libtensorflow-lite/libmace/libtnn/libbloops/barhopper library; all AI Factory model paths in the manifest point to .dnn.enc files inside a downloaded 'bloops' component; Looksery logs 'Failed to download NN face detector model.' for its optional NN detector. libcamplat does embed the MACE engine and NNAPI client but no weights."
}