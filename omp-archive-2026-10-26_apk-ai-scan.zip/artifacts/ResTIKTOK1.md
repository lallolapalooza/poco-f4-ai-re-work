{
  "status": "complete",
  "model_format": "ByteDance 'smash-face' bundle (not TFLite, not ByteNN/BM): 16B file id; u32 size@0x10; u32 version_len+version; u32 record_count; per record [u32 name_len, name, const 36, 32B per-file key A, const 32, 32B blob B, payload]. B[4] = descriptor-block size, always 4 mod 16 (struct-size artifact). Payload = dense binary graph descriptor (schema unknown) + raw weight bytes. 'mean' record = [u32 7620][1905 fp32 anchor-geometry values][8 zero].",
  "decoded": true,
  "models": [
    "tt_face_v10.0.model",
    "tt_face_extra_v13.0.model",
    "tt_face_attribute_age_v1.1.model"
  ],
  "reimpl_status": "architecture_only",
  "unknowns": [
    "smash-face descriptor-block schema (ops/tensors/offsets/quantization)",
    "per-record dtype and quantization",
    "exact input shape/layout/color per sub-model",
    "age output layout (regression vs logits)",
    "whether extra bundle is always loaded / AB flags",
    "consumer of decoded mean anchor geometry"
  ],
  "notes": "Deliverables in reports/tiktok_musically: report.md, findings.json (schema-valid), sources/, native/, models/ (bundles + carved sections + mean fp32), ir/ (container JSONs + mean weights), reimpl/ (model_container.py parser+carver, pipeline.py JAX, verify.txt, README), evidence/. Both programs exit 0. Container structure confirmed in all 12 records; AES/ChaCha/zlib/lzma/bz2 and the libbytenn XOR+inv-Sbox cipher all tested negative; libeffect.so path strings and espresso/Thrustor loader imports confirm the runtime path. Shared notes at reports/_shared_tiktok_format.md; cross-checked with ResTIKTOK2 (trill files byte-identical)."
}