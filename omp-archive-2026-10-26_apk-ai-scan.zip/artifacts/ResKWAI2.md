{
  "status": "complete",
  "variant_diff": "8146 vs 8130 zip members vs kwai_video; 79/80 native libs byte-identical by sha256, only lib/arm64-v8a/libcore.so differs (30,800 B); all 14 AI/vision libs identical. Differing members: 16 dex, 3 assets, 3200 res (PNG-vs-WebP icons, local/nearby UI removal), 26 only-bulldog res, 12 only-video res, 3 META-INF, 2 root. AI assets (BodySlimming params, beauty_list, deform_config, demo_* quality reports, fm_builtin_face_mask, eyemask, default_enhance_lut) are hash-identical.",
  "models_found": [
    "No bundled model files: 0 .tflite/.model assets; TFL3 in APK only as the TFLite schema string in libtensorflow-lite.so at 0x2f7c25; carve_models found no model container in any AI lib.",
    "libykit.so: ycnnnet v3/v4 runtime, 102 KSModel*.model names, 19 *_cfg families, 342 net_* names, 28 recovered config keys (net_w/net_h/inputMeanVals/model_type/model_sub_type/stride_*/nms_*/score_thresh/heatmap/landmark_param...), TFLite+NNAPI+SNPE-MTK-APU shims, KSJNILib JNI (createModel 0xc81e8, renderModel 0xc8360, updateModelOut 0xc8a54, YCNNGetConfig2Model 0xce798).",
    "libykit_core_plugin.so: YcnnPlugin/YcnnPluginUtils JNI (0x144bc..0x16640); libykit_plugin.so: YKitPlugin JNI (0xab3c); libykit_module_plugin.so: AIEditPlugin 0x14f50, MmuPlugin 0x15e58 (nativeGetFaceReplacedBitmap 0x166e4), YarPlugin 0x18f8c.",
    "Downloaded resources: KSModel*.model family (magic_ycnn_model_*), voice_detect_mode.tflite (resource key voice_detect_mode, EditorKveVoiceDetectParam.setModelPath), magic_mmu_model_*, effect packages containing ycnnModelPath/ycnnModelPathMap/bg_model.bin/fg_model.bin."
  ],
  "reimpl_status": "ARCHITECTURE_ONLY: reports/kwai_bulldog/reimpl/pipeline.py runs exit 0 (verify.txt) implementing NV21/NV12->RGB BT.601, ycnn crop/resize/inputMeanVals preprocess, detector heatmap+68-landmark heads with deterministic random init, and KVE feature statistics; no numeric parity possible because weights/graphs are downloaded.",
  "unknowns": [
    "ycnnnet .model container layout and per-model graph",
    "mapping from YCNNModelConfig model_type/model_sub_type to a specific KSModel*.model",
    "per-model net_w/net_h/inputMeanVals and landmark count",
    "exact CDN base-host composition (response carries url/suffix; host resolved at runtime)",
    "layout of a downloaded MagicFace effect package",
    "whether dynamic plugin APKs ship additional pre-baked models"
  ],
  "notes": "Model acquisition confirmed: ConfigResponse (voice_detect_mode_v1, model_matting_v1, modelResources, kwaiPreloadModels) + YlabModelConfigResponse (resourceKey -> urls[{cdn,url}]) -> MagicModel.getInitDownloadUrl -> download/unzip to <cache>/.magic_model/magic_model/<key> or <cache>/magic_effect_resource/<key> -> check.json MD5 validation -> path handed to FaceDetectorContext.setData, FaceMagicController.setExternalBuiltinPath/BeautifyExternalBuiltinPath, YcnnPlugin.nativeSetParamInfo({\"attr_local_path\":...}), KSJNILib.createModel. Files: reports/kwai_bulldog/{report.md, findings.json (validated), sources/index.md + 13 jadx classes, native/ (ELF JSON, JNI tables, 2 disassemblies, libs), models/assets/, ir/ykit_model_registry.json, reimpl/{pipeline.py,README.md,verify.txt}, evidence/}."
}