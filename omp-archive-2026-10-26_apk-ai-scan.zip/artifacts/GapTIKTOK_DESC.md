{
  "status": "descriptor decoded; 11/12 records decrypt to net text, 6 execute with real weights, 4 with byte-exact weight buffers",
  "records_decoded": 11,
  "runner": "reimpl/run_record.py (numpy; Convolution, DepthwiseSeparable, Pooling MAX/AVE+global, Eltwise, InnerProduct, Softmax, ReLU, Sigmoid, Concat)",
  "blockers": [
    "agenet auth_code (tt_face_attribute_age_v1.1.model) not recovered — 1 of 12 records. Ruled out: all 756 48-char alnum literals in libeffect.so, all 24 codes decoded from `bl 0xa97bdc` sites, the 5 partial 47/49-byte scans (1-edit sweep tested), and the rodata literal IMvV6VBo… at 0xd66dc6. Next: decompile the FaceAttributesTask loader at libeffect xref 0xafdd54 (string 0xd9283f).",
    "weight fixed-point dequantisation scale not recovered — int8/int16 weights (layer line ints[9] = 1/2) + int32 bias verified by exact buffer closure, but no float32 scale exists in the buffer at any phase. run_record.py --wscale applies 2**-n; outputs are therefore NOT claimed bit-exact with the effect SDK.",
    "Slice/Split multi-top layer lines not modelled, so base120/partface/iris/extra parse (3..141 layers) but do not close their weight buffers and do not execute."
  ],
  "files": [
    "reports/tiktok_trill/reimpl/descriptor.py",
    "reports/tiktok_trill/reimpl/run_record.py",
    "reports/tiktok_trill/reimpl/verify.py",
    "reports/tiktok_trill/reimpl/verify.txt",
    "reports/tiktok_trill/reimpl/GAP_CLOSURE.md",
    "reports/tiktok_trill/reimpl/coverage_fragment.json",
    "reports/tiktok_trill/reimpl/README.md",
    "reports/tiktok_musically/reimpl/descriptor.py",
    "reports/tiktok_musically/reimpl/run_record.py",
    "reports/tiktok_musically/reimpl/verify.py",
    "reports/tiktok_musically/reimpl/verify.txt",
    "reports/tiktok_musically/reimpl/GAP_CLOSURE.md",
    "reports/tiktok_musically/reimpl/coverage_fragment.json",
    "reports/tiktok_musically/reimpl/README.md",
    "reports/tiktok_trill/native/bytenn_parseNet_decompiled.c",
    "reports/tiktok_trill/native/libeffect_loader_decompiled.c",
    "reports/tiktok_trill/native/libeffect_modelpkg_decompiled.c"
  ],
  "notes": "SOLVED. The 'opaque descriptor block' is AES-256-ECB-encrypted net-description TEXT.\n\nContainer (ModelPackage), byte-exact to EOF on all 3 files: [16B file id][u32 size][u32 version_len][version][u32 num_model] then per model: [u32 name_len][name][u32 key_len=36][key][u32 checksum_a][u32 config_len][config][u32 checksum_b][u32 weight_len][weight].\n\nCrypto: each model has a 48-char auth_code built as inline immediates in libeffect.so (validated to len 48 by rodata 0xd66933); AES key = auth_code[0:32] (ELF 0x6b2984-0x6b299c, 'mov w2,#0x20'). Primitive FUN_0x9ce7d0 is AES with the standard key schedule (SubWord ELF 0x70d298, RotWord byte-store/LE-reload, Rcon xtime 0x1b1b1b1b) over independent 16-byte blocks => AES-256-ECB. Field format [ciphertext, len-4, multiple of 16][u32 plaintext_len] — exactly the old reported (len-4)%16==0 invariant. key_field (36B) decrypted with auth_code[0:32] yields the 32-byte net key which decrypts config.\n\nAuth codes: tt_face_v10.0 = vVwfzV4dKMAdxYEcLJ15Bb5tm0b4I7HhozHgk1z9vYW5GIov (loader ELF 0x68a628); v13.0 = WaPdHZfZiMCQM2Ds6xMz9Rpva068vCyFMHPryDt0dhfUONtS (loader ELF 0x68b6f8). Extraction method: 7 register immediates + 40 `str wN,[sp,#8k]` stores recovered by a forward movz/str data-flow scan; validated by reproducing the base code bit-exactly. 24 of 29 such sites in libeffect.so decode cleanly.\n\nNet text: line 1 optional tag (B/E), then `version declared_layers [magic]`, then one line per layer; libbytenn IESNN::parseNet (ELF 0x140788) + StringParser::NextLine/NextString. Records are 3..141 layers (data/DataV2, Convolution, DepthwiseSeparableConvolution, Eltwise, Pooling, InnerProduct, Softmax, Slice, Concat). ints[9] is the weight element size (1=int8, 2=int16).\n\nWeights: per weight-bearing layer [int8|int16 weights][int32 bias]. Byte-exact closure: detect 14448/14448, base120det 151168/151168, image 81880/81880, slowimage 92296/92296; detect's first bias block reads [1410,2945,2168,2135,2027,-396,8749,9263] as int32 (8 sane biases for 8 output channels).\n\nmean record fully decoded: config plaintext is the single byte '1'; weight = 7620 B = 1905 float32 (range -2.769..255.241) = the anchor/prior table.\n\nExecuted with real weights: detect 1x3x128x128 -> rpn_bbox_pred/32s 1x12x4x4 (54 layers, 39 weighted tensors); image 1x3x160x160 -> 1x12x5x5; slowimage 1x3x192x192 -> 1x16x6x6; pout 1x3x56x56 -> prob 1x2x1x1 (softmax sums to 1, residue 385 = InnerProduct f32 + 1 B); mean 1905 f32.\n\nreimpl/verify.py exits 0 in both variants (0 failures); verify.txt holds the transcript. Both tiktok_trill and tiktok_musically reimpl/ are now identical (identical models/libs). Pre-existing placeholder files (model.py, model_container.py, pipeline.py, validate_findings.py) were left in place because report.md cites them, and are marked superseded in README.md."
}