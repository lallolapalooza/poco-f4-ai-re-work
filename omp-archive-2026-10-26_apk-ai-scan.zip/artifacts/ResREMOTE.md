{
  "status": "complete",
  "on_device": [
    "Mic capture: AudioRecord(1=MIC, 16000 Hz, 16-bit, 2=mono) loop in com.xiaomi.ai.c (~lines 179-215) feeding MibrainRequest.addData",
    "Local VAD: libmibrainsdk.so exports vadInit(0x16e20)/vadCheckBegin(0x16fdc)/vadCheckEnd(0x1711c)/vadUninit(0x1722c); used when AsrRequest.setUseVad(true) + VadMode.VAD_MODE_LOCAL (both app defaults, AsrRequest.java:35-40); internal detector at 0x41de0 (log/exp based)",
    "Second NN VAD (shipped, unused by this APK): libmibrainvad2.so CornVad/Soil engine, JNI MibrainVad2.newVad/createTask/hasVoice/stopTask/releaseVad, embedded model mdata_vad (symbol 0x4fd90, 1,132,916 B, mdata_vad_length@0x164704) with version vad_2.1.0_0",
    "Model graph (9 Soil components, recovered exactly): input 840 -> affine 840x300 + b300 -> pnorm(out_size=100) -> affine 300x100 + b300 -> pnorm(100) -> normalize(100,divide,rms=1.0) x2 -> affine 100x2 + b2 -> softmax(num-pdf=2); weight offsets in the extracted blob: W1@51 (1,008,000 B), W3@1009287 (120,000 B), W7@1130595 (800 B)",
    "Feature front-end constants from CornFeatureInitialize(0x32b50): 16 kHz, 25 ms frame (400 samples), 10 ms shift, pre-emphasis 0.97, Povey window (exp 0.85), 512-pt FFT; conf: 40 mel bins 40-7800 Hz, 40 cepstra, use-energy=false, left/right context 10, num-pdf 2, smooth-win 5, min-voice 50, min-sil 60",
    "Opus encoder inside libmibrainsdk (libopus; Opus-Frame-Size 640/1280, 32/64 kbps) or raw PCM (USE_ENCODER_PCM=1)",
    "TTS decode: libmibraindec.so = libmad 0.15.1b ('MPEG Audio Decoder 0.15.1 (beta)'), JNI MibrainMp3Decoder.newInstance/start/stop/cancel/deleteInstance -> PCM -> AudioTrack",
    "IR/BLE command execution after intent routing: cg.l -> cg.a/cg.b/cg.f(tvChannelControl)/cg.g handlers -> ee.j device -> TRANSMIT_IR / BLE"
  ],
  "cloud": [
    "ASR/NLU/TTS over WebSocket+TLS: wss://speech.ai.xiaomi.com/speech/v1.0/access (prod), wss://speech-sgp.ai.xiaomi.com, wss://speech-preview.ai.xiaomi.com, ws://speech-staging.ai.xiaomi.com (libmibrainsdk .rodata 0xb87c0-0xb8930)",
    "Voiceprint: wss://speech.ai.xiaomi.com/speech/v1.0/vor (+sgp/preview/staging)",
    "Debug audio upload: /speech/v1.0/dump; wakeup-data upload (WAKEUP_AUDIO, max 60 s)",
    "Resource locator: https://api.ai.xiaomi.com/cp_resource_locator/c/v1.0/provider/%s/ids/%s ; tracking /track/v1, /track/authmiot, /track/perf",
    "OAuth: https://account.ai.xiaomi.com/oauth2/auth/token?grant_type=authorization_code|refresh_token... and anonymous %s/anonymous/app/auth/token",
    "Auth headers: DO-TOKEN-V1 / MIOT-TOKEN-V1 / TP-TOKEN-V1 / AO-TOKEN-V1 / AA-TOKEN-V1 (app_id, scope_data, access_token, api_key, signature)",
    "Message contract: protobuf frames tagged AI_CMD_ASR / AI_CMD_PRE_ASR / AI_CMD_NLP / AI_CMD_TTS, responses RESULT_ASR_PARTIAL|FINAL, RESULT_NLP, RESULT_TTS_BEGIN|URL|END; NLP answer JSON with intention.domain/entity/action, content.to_speak/to_display, open_mic, vad_idle (SpeechEngine$ResultParser)",
    "App credentials: SpeechEngine.createEngine(ctx, 1, '2882303761517406041', '5141740612041'), env 0 (CN) or 3 (SGP), UA 'MiRemote; Sensy/1.56 Build/<n> Channel/Release OS/Android' (cg.l.java:46-55, 536-552)",
    "XiaoAi/MVS alternative path: bind com.miui.voiceassist.mvs.server.MvsService (AIDL IMvsTransition, broadcast ACTION_RESGISTER_MVS, permission com.miui.voiceassist.MVS_BROADCAST); recognition performed by the system assistant"
  ],
  "reimpl_status": "runs_unverified — cd reimpl && python pipeline.py exits 0; real affine weights (W1 300x840, W3 300x100, W7 2x100) extracted from models/vad_2.1.0_0.binn; JAX forward + Kaldi-style MFCC/CMVN/±10-frame stacking + posterior smoothing/decoder; pnorm/normalize arithmetic and CMVN scaling are ARCHITECTURE_ONLY; no numeric comparison against the ARM library (no aarch64 execution environment)",
  "unknowns": [
    "Exact arithmetic of ComponentPnormPropgate and ComponentNormalizePropgate (only their configuration is in the model file)",
    "Semantic/scale of the embedded CMVN array (82 floats, magnitudes ~1e10-1e12, 41 dims vs 40 cepstra) — feature domain (log vs linear power) unresolved",
    "Classic VAD inside libmibrainsdk.so (vadInit 0x16e20, detector 0x41de0) not fully reversed",
    "Protobuf schema and cloud ASR/NLU/TTS models (only message ids and field-name strings recovered)",
    "Whether vad_2.1.0_0 is ever activated at runtime — no Java reference to MibrainVad2 exists in this APK",
    "The 'Tap to install iFly voice engine' prompt has no code reference in any dex string table; the external engine package is unknown"
  ],
  "notes": "Deliverables in reports/miui_remote/: report.md (295 lines, evidence-cited), findings.json (validated against SCHEMA.json via evidence/validate_findings.py), sources/ (18 jadx single-class files + index.md), native/ (elf_info JSON/text for 5 libs, 48-function Ghidra pseudocode native/ghidra_vad2.c, 30+ disassemblies in native/asm/), models/ (vad_2.1.0_0.binn, 1,132,916 B, sha256 5e4d9ff4…), ir/ (vad_model_ir.json, vad_config.json, vad_cmvn.json), reimpl/ (soil_binn.py parser, vad_model.py, frontend.py, pipeline.py, verify.txt, README.md), evidence/ (cmd.txt, hashes.txt, dex string/xref dumps, manifest dump, validator). Key structural result: the vad2 blob is a soil-binn container {list:[{am:1,131,400 B Soil binary net},{conf:373 B},{cmvn:1080 B text}]}; the Soil binary was decoded by reimplementing ComponentLoad + LoadDependence (type ints: 1=input, 8=affine, 15=pnorm, 17=normalize, 19=softmax; each record followed by [n_dep][dep ids]) and the parser consumes the stream to the exact last byte, confirming the graph. The app itself never calls MibrainVad2; its ASR/NLU/TTS are cloud-side."
}