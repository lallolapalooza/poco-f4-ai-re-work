{
  "status": "complete",
  "pipeline_file": "reports/snapchat/PIPELINE.md",
  "pipelines": [
    "lens_cv_camera",
    "mlkit_barcode_face",
    "aifactory_deferred_dnn",
    "libclient_learned_search_voiceml",
    "memories_face_clustering"
  ],
  "gaps_closed": [
    "Camera/GL producer -> lens trace: rk6.a -> Hs8.b (LensesCameraFeatureProcessingCoreSub) -> WA4.e -> LSCoreManagerWrapper.processFrameToTexture -> nativeProcessFrameToTexture @0x767500 -> LS::TrackingManager::track -> FaceDetectorStage/TrackingStage/NaturalFeatureTracker/Scenarium -> drawTexture @0x767a00.",
    "Transport contract confirmed: GL_TEXTURE_EXTERNAL_OES 36197 vs GL_TEXTURE_2D 3553 selected by rk6; ns timestamp with TimestampConverter clock-offset correction; two float[16] matrices; width/height; Size.OPTIMAL_FOR_PROCESSING=600x800 cap; 0/90/180/270 rotation via setCameraParams(59,-1,0 defaults); front flag; EGL render-thread enforcement and optional async tracking.",
    "Data contracts documented: Haar uint8 gray integral image + 20x20 20-stage/1047-tree cascade; ERT chain FaceRegressor(0.76)->Eyes->Denoise->Candide->Perspective with 68/98 landmark outputs and undecoded 0x53 payload patch size; ORB FAST-9/r10/BRIEF-256 + 20x2 tree; 118/124-triangle mesh over indices 0..75; exact facestretchLiquify.glsl uniforms/inputs/outputs.",
    "Explicit no-bundled-DNN statement added: inventory model_assets=0/ai_libs=0, 6869 entries scanned with 0 TFL3 hits; MACE/TFLite/NNAPI/TNN code present but no weights or TFLite/TNN library.",
    "External boundaries added: ML Kit barcode/GMS face GmsCore binder contract (BarcodeScannerImpl/MobileVisionBase/FaceParcel; manifest DEPENDENCIES); AI Factory .dnn.enc download + ModelCrypto AES + MACE/TNN bloops path with manifest model paths; libclient ModelCoordinator/ModelFileBuffer + VoiceML; Memories FaceClusteringJob server-side inference.",
    "PIPELINE.md created with all 9 template sections; report.md addendum + link added; findings.json gained a schema-valid data_pipelines array (5 entries) plus 4 new unknowns; evidence 07/08/09, native/jni_binding_table.txt, libclient_strings.txt, new decompiled sources, native README/index updates."
  ],
  "remaining_unknowns": [
    "Exact Camera2 capture delegate/session feeding the lens OES texture (rk6/Hs8 identified; rotation/resolution source inferred from frame state).",
    "Haar runtime defaults (scale factor, min face size, minFaceInImageRatio) not extracted numerically.",
    "ERT patch size and packed 0x53 regressor tree/node layout remain undecoded.",
    "ORB RANSAC/robust-estimator parameters and TrackingManager queue drop policy not recovered.",
    "AI Factory bloops/TNN/MACE runtime choice remains inferred (no shipped component); ML Kit IPC detail and Memories server contract inferred."
  ],
  "notes": "Validated with system jsonschema against SCHEMA.json (jsonschema OK), json.tool parse OK, PIPELINE.md has 9 numbered sections. No bundled DNN; the per-frame path is classical CV. Key refs: report.md 'Data-path addendum', evidence/07_camera_lens_trace.txt, evidence/08_external_boundaries.txt, evidence/09_validation.txt, native/jni_binding_table.txt. Did not rerun reimpl/verify.py (unchanged)."
}