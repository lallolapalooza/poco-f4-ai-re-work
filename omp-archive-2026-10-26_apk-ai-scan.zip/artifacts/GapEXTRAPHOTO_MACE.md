{
  "status": "PARTIAL — embedded MACE document models separated, extracted and verified (5 description blocks, 6 fp16 weight buffers = 18,650,700 B, 466 constant tensors with byte ranges and fp16 decoders); operator graph NOT recoverable from this binary, so no inference is claimed or implemented.",
  "parser": "reimpl/mace_loader.py — stdlib parser (numpy only for fp16 statistics) for the embedded MACE model grammar: (1) finds the five block trailers `u32 0, u32 payload_bytes` at 0x16020d8/0x1605be0/0x16071e8/0x1609560/0x160a030; (2) parses each block's NUL-terminated name stream (MACE op types/arg names/tensor names) and its 16-byte table of `u64 byte_offset, u64 fp16_element_count` records; (3) discovers the six constant-returning getters in .text (`adrp x0/add/ret` paired with `movz/movk/ret` 12 B later, all called from the MacePlatform loader at 0xafbb0) that give the proven payload base+size of every weight buffer; (4) joins block→payload by trailer size, decodes every const tensor as fp16 and reports per-tensor stats; (5) parses the model interface descriptors (hed_model 1x384x384x3->1x384x384x2, enhance_model 1x512x512x3, dewarp_fine_model [1,193,193,3]+[1,385,385,3]->[1,385,385,2]); (6) `--extract` carves names/tables/weights/tensor indexes + MANIFEST.json, `--check` re-verifies sizes+sha256+range invariants, `--self-test` runs the whole grammar on a synthetic .rodata image (exit 0), `--report`/`--json` emit the human/machine report. Contract: graph_decoded=false, inference_available=false; it never fabricates ops or shapes.",
  "blobs": [
    "models/embedded/mace/block0_16020e0.payload00.87cc.weights.f16.bin (0x4387cc, 578,656 B)",
    "models/embedded/mace/block1_1605be8.payload01.5cb0.weights.f16.bin (0x4c5cb0, 1,323,252 B)",
    "models/embedded/mace/block1_1605be8.payload02.8e28.weights.f16.bin (0x608e28, 1,323,252 B)",
    "models/embedded/mace/block2_16071f0.payload03.bfb4.weights.f16.bin (0x74bfb4, 3,164,748 B)",
    "models/embedded/mace/block3_1609568.payload04.0a98.weights.f16.bin (0xa50a98, 10,997,360 B)",
    "models/embedded/mace/block4_160a038.payload05.ef8c.weights.f16.bin (0x14cef8c, 1,257,800 B)",
    "models/embedded/mace/block{0..4}_*.names.bin — name streams (13,346 / 3,049 / 8,151 / 1,858 / 9,635 B)",
    "models/embedded/mace/block{0..4}_*.tensors.u64.bin — raw (offset, element_count) tables (105/160/57/56/88 records)",
    "models/embedded/mace/block{0..4}_*.tensors.json — per-const-tensor byte range + fp16 stats",
    "models/embedded/mace/MANIFEST.json — offsets, sizes, sha256, payload law verdicts, tensor indexes"
  ],
  "files": [
    "reimpl/mace_loader.py",
    "reimpl/GAP_CLOSURE.md",
    "reimpl/coverage_fragment.json",
    "reimpl/verify.txt",
    "reimpl/mace_report.json",
    "reimpl/README.md (added mace_loader row + section)",
    "models/embedded/mace/ (21 files + MANIFEST.json)",
    "evidence/mace_refscan.py",
    "evidence/mace_refscan.txt",
    "evidence/mace_loader_notes.txt"
  ],
  "blockers": [
    "Operator graph: no MACE NetDef/protobuf exists in the image. Every model name occurs only as a C string (hed_model x1, enhance_model x3, EdgeDet/MobilenetV1 x92, inference/generator x469) with 0 protobuf-framed occurrences (0x0a/0x22 + length), so op types, attributes, wiring and per-tensor shapes are unavailable. MacePlatform builds a MultiNetDef object at run time (loader FUN_001afbb0, per-case builders 0xb16ac/0xb1840/0xb19d4/0xb1b68/0xb1cfc/0xb1e90 logging 'Create multi net ') and takes the net_def from a .bss registry at 0x17ee418 filled at run time — not statically resolvable here.",
    "The five description blocks at 0x16020d8..0x160cb60 are referenced by nothing: 0 R_AARCH64_RELATIVE relocations, 0 movz/movk absolute constants, 0 64-bit literal-pool constants, and the only adrp+add hits inside the region are MACE log literals interleaved with the name streams ('Create operator ' x488, 'Create tensor ' x627, 'Create net ' x6). The six weight getters (one adrp+add and one movz+movk per buffer) are the only code link to the model bytes.",
    "Block 3 (switch case 8, the 11 MB resnet autoencoder) has 0x120000 B of payload undeclared by its table — exactly two 0x90000-element tensors; its payload law is therefore marked NOT verified (slack 0x120000, coverage 0.5) while blocks 0/1/2/4 verify with slack 2/0/0/0 B and coverage 1.0.",
    "Model-name -> model-id map is unresolved (no {char*,int} table relocates to the model name strings) and switch cases 5-7 carry no data, so three of the nine named models ship without weights; which of the two identical-size dewarp payloads (0x4c5cb0 / 0x608e28) is coarse vs fine cannot be decided from static data.",
    "Per-tensor shapes/dtype are not stored: a record carries only (byte_offset, fp16_element_count). fp16 is derived from the exact 2-bytes-per-element packing law (zero-gap packing + trailer==2*max_tensor_end), not from a declared dtype tag."
  ],
  "notes": "Proven results: description region 0x16020d8..0x160cb60 (43,656 B, 5 blocks, 466 tensors). Weight buffers 0x4387cc, 0x4c5cb0, 0x608e28, 0x74bfb4, 0xa50a98, 0x14cef8c tile 0x4387cc..0x16020d4 exactly: 18,650,700 B payload + 700 B alignment gaps (0x84,0x84,0x98,0x98,0x84) = 18,651,400 B = the region size. Record law: u64 byte_offset + u64 fp16_element_count, body 2*count bytes. Mapping: block4 = hed_model/ScanModel (EdgeDet/MobilenetV1 names, pred_segment output, 384x384x3->384x384x2) confirmed; block1 = the dewarp coarse+fine pair (one table, two equal-size payloads, switch cases 2/3) confirmed; blocks 0/2 = the two inference/generator nets (enhance vs demoire unresolved, inference); block3 = largest net, switch case 8 (inference: handwrite). Corrections recorded in GAP_CLOSURE.md §10: (a) the embedded MACE models ARE separable (contradicts GAP list / REIMPL_COVERAGE), (b) the 0x4d3700..0x78c700 region is fp16 with -0.0 (0x8000) padding, not int8 0x80 zero-point, (c) dewarp_fine descriptor 0x437ea0 holds three arrays [1,193,193,3],[1,385,385,3],[1,385,385,2]. Verification: reimpl/verify.txt records self-test (synthetic image, exit 0), report, extract, check (21 files / 466 tensors / 0 errors) and refscan (exit 0); all JSON artefacts validate. Scratch scan scripts were deleted; only the two reproducible evidence scripts remain."
}