{
  "status": "complete",
  "pipeline_file": "reports/miui_extraphoto/PIPELINE.md",
  "pipelines": [
    "A. Document photo: DocPhotoActivity/DocPhotoPostProcessingActivity -> DocPhotoManager/DocProcessor -> DocumentProcessJNI -> libdoc_photo_process.so (MACE) -> Bitmap -> JPEG/XMP/MediaStore",
    "B. Portrait relighting: RelightingOperatingFragment -> MiBrainRelightingProcessor -> MiDualPhotoJni -> libmibrain_relighting_jni -> AILAB_PLI_* -> GLES light-map shader -> NV21 -> Bitmap/YUV display -> JPEG",
    "C. Dual-camera bokeh: AdjustOperatingFragment -> MegviiAdjustProcessor -> MegviiDualPhotoJni -> libmegvii_bokeh_jni -> wa::Refocus::setImages/run -> NV21 -> Bitmap -> JPEG"
  ],
  "gaps_closed": [
    "Document path traced end-to-end with exact Java methods (DocPhotoActivity.onCheckPermissionSucceed, DocPhotoManager.render/renderPreview, DocPhotoProcessor doScan/doCrop/doEnhance/doCropAndEnhance/doUndistortion/doDeHandwrite), JNI descriptors, Bitmap ARGB_8888-only contract, RGBA->RGB->RGBA staging, 384x384x3->384x384x2 ScanModel and 512x512x3 EnhanceModel, warp/enhance/dewarp/handwrite, preview-vs-save, JPEG q97 + EXIF/XMP/raw-append consumer.",
    "Relighting path traced with exact JNI signatures, ASVL_OFFSCREEN/NV21 buffer layout, AILAB_PLI Init/PreProcess/SetLightSource/Process/GetLightSource call arguments, degree->orientation mapping, GLSL shader inputs/outputs, YUV/RGB output, and the finding that the brain JNI always centres the light (setLightSource is a no-op, supportAdjustLightSource=false) while ArcSoft forwards real gesture coordinates.",
    "Bokeh path traced with JNI signature, three wa::Image descriptors (ImageType/DataType constants), focus coordinate space (process-bitmap pixels), 25-entry F_VALUE -> 9-aperture ALG_F_VALUE mapping, NV21 output-to-Bitmap conversion, render-handler threading, and save-time full-res re-run.",
    "Consumer section documents preview vs save for all three pipelines, threads, encoders (doc JPEG 97; relight/bokeh JPEG 100), metadata handling (docPhoto XMP, stripped depth/focus tags), MediaStore/setResult delivery, and failure/fallback paths.",
    "PIPELINE.md written with the required 9 sections per pipeline; data_pipelines (3 entries) added to findings.json and validated against SCHEMA.json; report.md extended with an evidence index update and section 10 addendum."
  ],
  "remaining_unknowns": [
    "Shipping document scan model weights remain embedded in libdoc_photo_process.so and were not extracted; the ScanModel is 384x384x3->384x384x2, not the shipped DLC's 512x512x3->512x512x1.",
    "Whether the SNPE document_model.dlc is consumed by any loader in this build: libdoc_photo_process.so is MACE and has no SNPE/.dlc parser strings; the file is copied and passed to nativeInit but its consumer is unobserved.",
    "Whether the /255 normalisation is inside the embedded MACE ScanModel graph or applied by an unobserved native stage (inferred from the equivalent DLC's leading Div(255)).",
    "AILAB_PLI_PreProcess/Process internals and the 82.9 MB opaque .data payload of librelight_only_extraphoto.so (light textures/3D LUTs) were not decoded.",
    "wa::Image::ImageType/DataType numeric enum labels are inferred (6 = NV21 image, 0 = depth, 0/1 = 8/16-bit depth); only the constants are confirmed.",
    "Exact quad-postprocess algorithm (calcQuad/minAreaQuad/IOU) and ScanModel float parameters' roles are inferred from strings and call sites, not from a full decompilation of FUN_00182a80."
  ],
  "notes": "Evidence added: native/doc_jni_ghidra.c (20/20 DocumentProcessJNI functions decompiled), native/doc_core_ghidra.c (scan/crop/enhance/quad-validate/clamp), native/wa_refocus_ghidra.c (Refocus entry points), 12 new disassembly/hexdump files, evidence/09_doc_pipeline.txt and evidence/10_relight_bokeh_pipeline.txt, plus decompiled sources under sources/docphoto_flow, sources/relight_core, sources/refocus_core. Key corrections: the shipping MACE scan model is 384x384x3->384x384x2 (the 512x512x3 descriptor belongs to enhance_model); the brain relighting touch gesture is dead in this build (JNI always W/2,H/2,W,H). Verification performed: python3 -m json.tool and jsonschema 4.26.0 validation of findings.json against SCHEMA.json (3 data_pipelines, schema OK). No build/test suite applies to this report patch."
}