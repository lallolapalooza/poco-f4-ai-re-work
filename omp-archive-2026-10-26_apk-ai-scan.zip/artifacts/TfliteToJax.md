{
  "status": "complete",
  "files": [
    "/run/media/user/00000000-0000-4000-8000-000000000000/re_work/tools/tflite_ir.py",
    "/run/media/user/00000000-0000-4000-8000-000000000000/re_work/tools/tflite2jax.py",
    "/run/media/user/00000000-0000-4000-8000-000000000000/re_work/tools/verify_tflite_jax.py",
    "/run/media/user/00000000-0000-4000-8000-000000000000/re_work/tools/tflite_to_jax_example.py",
    "/run/media/user/00000000-0000-4000-8000-000000000000/re_work/tools/README.md",
    "/run/media/user/00000000-0000-4000-8000-000000000000/re_work/tools/tests/mini_tflite.py",
    "/run/media/user/00000000-0000-4000-8000-000000000000/re_work/tools/tests/test_tflite_jax.py"
  ],
  "passing_models": [
    "asi__line_model.tflite",
    "gmscore__ranker.tflite",
    "gmscore__rc_ranker.tflite",
    "gmscore__rc_segmenter.tflite",
    "gmscore__segmenter.tflite",
    "modemtestbox__0.3_new_0410_less.tflite",
    "phonesky__notification_clickability.tflite",
    "photos__trigger_model.v0.2.3.tflite",
    "photos__trigger_model_me.v2.27.0.tflite"
  ],
  "failing_models": [],
  "unsupported_ops": [
    "CUSTOM:UnsortedSegmentProd (adservices, 6 ops, first index 68)",
    "GELU (adservices, 6 ops, first index 83)",
    "CUSTOM (messages, 7 ops, first index 3) plus STRING tensors",
    "VAR_HANDLE/READ_VARIABLE/ASSIGN_VARIABLE/CALL_ONCE (securitycoreadd, all 7 subgraphs stateful)"
  ],
  "notes": "Deliverables are in $WS/tools, docs appended to the shared README.md without touching APK/DEX or native sections. Full 12-model matrix completed earlier: 9 PASS / 3 SKIP / 0 FAIL, all passes max_abs <= 5.7e-06 (strict float tolerance 1e-4), including the 4 gmscore hybrid-int8 models (per-row/per-batch TFLite hybrid input quantization reproduced, asymmetric clamp [-128,127]) and the uint8/photos models. Skipped with machine-readable JSON: adservices (status=custom_op_unsupported; 6 CUSTOM UnsortedSegmentProd + 6 GELU), messages (custom_op_unsupported; 7 CUSTOM + STRING tensors), securitycoreadd (stateful_unsupported; subgraph roles reported: 0/1 inference, 2 restore, 3/4 save, 5 train, 6 init; exact op list per subgraph). Main gap vs parent's list: adservices cannot execute because of the CUSTOM UnsortedSegmentProd ops (GELU alone is trivial); it fails cleanly rather than crashing. After the last non-corpus edits (space_to_depth ordering, FLOOR_DIV, depthwise hybrid, verifier dtype assertion, IR input/output detail objects) 40/40 tests pass and representative models (asi, rc_ranker, photos) were re-verified; the final full-corpus rerun was stopped per the time-box after 2 models (both pass), so the 9-pass matrix is from the preceding full run with numerically identical conversion code. Verification uses ai_edge_litert reference kernels (BUILTIN_WITHOUT_DEFAULT_DELEGATES, no XNNPACK) because XNNPACK hybrid numerics differ from the TFLite reference; JAX also works under jax.jit (ranker compile 0.8 s, repeat 0.8 ms). Commands: python tflite_ir.py MODEL [--out f.json]; python tflite2jax.py MODEL --out DIR [--subgraph N|--signature KEY]; python verify_tflite_jax.py MODEL_OR_DIR [--out DIR --json r.json]; python tflite_to_jax_example.py MODEL_OR_DIR --out DIR. Generated model.py imports only stdlib os + numpy + jax and loads params.npz next to itself; init_params()/apply(params, *inputs), single output returned directly, multiple as a tuple; verified standalone in a fresh subprocess with no PYTHONPATH. Limitations documented: static shapes/batch, float32 emulation of fully-int8 activation graphs (int32 quantized biases are not dequantized), verifier only runs subgraph 0, CUSTOM/STRING/stateful unsupported."
}