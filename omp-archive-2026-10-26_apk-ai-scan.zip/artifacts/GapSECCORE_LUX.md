{
  "status": "complete",
  "files": [
    "reports/miui_securitycoreadd/reimpl/pipeline_lux.py",
    "reports/miui_securitycoreadd/reimpl/verify_lux.txt",
    "reports/miui_securitycoreadd/reimpl/GAP_CLOSURE.md",
    "reports/miui_securitycoreadd/reimpl/coverage_fragment.json",
    "reports/miui_securitycoreadd/reimpl/README.md",
    "reports/miui_securitycoreadd/reimpl/verify.txt"
  ],
  "cases": [
    "dark 0 lux / cat 0 → 3.858 nits (student 0.0000)",
    "dark 1 lux / cat 1 → 3.858 nits",
    "indoor 50 lux (span 6) / cat 7 photo → 70.813 nits",
    "indoor 200 lux (span 8) / cat 3 music/read → 95.014 nits",
    "indoor 1000 lux (span 15) / cat 9 social → 163.812 nits",
    "outdoor 5000 lux (span 31) / cat 1 game → 469.056 nits",
    "outdoor 20000 lux (span 42) / cat 2 video → 706.069 nits",
    "outdoor 100000 lux (span 44) / cat 0 → 944.371 nits",
    "category sweep 0..9 at 200 lux → 95.116 … 94.946 nits (finite)",
    "lux→span port: 15 boundary points (30/900/3500/10000/15000/35000/65000 lux) all match",
    "rejection gates: NaN / ±inf / negative → InvalidPrediction; bad event → -1.0 sentinel and currentBrightness fallback",
    "monotonicity over 20-point lux sweep, categories 0/1/2 → non-decreasing",
    "interpreter cross-check vs shipped flatbuffer: old max|err| 1.83e-4 nits, new 2.38e-7"
  ],
  "notes": "pipeline_lux.py: (ambientLux, luxSpanIndex, appCategoryId) → x=[ln(lux+1), ln(span+1), ln(cat+1)] float32 (1,3) exactly per f3.c.a/g3.a.a → model.py → nits, mirroring IndividualModelService$a.predictBrightness (sentinel -1.0f, currentBrightness fallback) and CustomBrightnessModeController.onPredictFinished (NaN/<0 drop). Verified: `$PY reports/miui_securitycoreadd/reimpl/pipeline_lux.py` exits 0, RESULT PASS, 8/8 finite, nits 3.858..944.371; second run with --nit-bounds 0 1740 also exit 0 (verify_lux.txt). KEY FINDING: the task said run new_model_infer, and it is run+reported, but on the shipped asset dnn_model_1/* has zero biases + Glorot kernels (untrained student, outputs 0.0..2.86) while dnn_model/* (old_model_infer) is the trained checkpoint; the app calls only old_model_infer, so `nits` = old_model_infer (units nits, C) and `student_nits` is reported and flagged non-servable. Normalized value: normalize_nit() reproduces IndividualEventNormalizer.normalizeNit (MathUtils.norm+constrain) but its bounds are device DisplayConfig (U), so they are a required argument; default column uses explicitly-labelled illustrative [2,1800]. getBrightnessFromNit LUT not in APK → dbv_from_nit_config() raises with explanation. model.py untouched; verify.txt kept as model-level transcript with a short §F pointer. Suggested main-agent checks: rerun `$PY reimpl/pipeline_lux.py` and diff `reimpl/verify_lux.txt` for PASS."
}