{
  "status": "complete",
  "pipeline_file": "reports/kwai_bulldog/PIPELINE.md",
  "pipelines": [
    "bulldog.camera_face_detect",
    "bulldog.faceless_effect_render",
    "bulldog.ycnn_plugin_providers"
  ],
  "gaps_closed": [
    "Gap 1 - producer/format/dimensions/rotation: libdaenerys.so 0xe18d8 DaenerysFrameObserver.nativeOnVideoFrameCaptured -> com.kwai.camerasdk.video.VideoFrame -> kuaishou::android::VideoRawFrameFromJni 0xece3c (6048 B). Frame-type dispatch decoded (type 1 YUV -> MediaDataType 35, 3 RGBA -> 38, 4 Bitmap, 2 TEXTURE -> GL texture ctor) plus the full JNI field table with .rodata offsets; rotation carried in VideoFrameAttributes.transform{mirror,rotation,crop_*_frac} with transformedWidth/Height semantics. Variant diff confirmed: VideoFrame defined in kwai_video classes15.dex, absent from all bulldog DEX.",
    "Gap 2 - JNI contracts: nativeDetectFacesFromFrame 0x1a19c trace (VideoRawFrameFromJni -> C++ virtual [ctx iface vtable+0x68] @0x1a24c -> per-face SerializeToString 0x1a6f8 -> NewByteArray/SetByteArrayRegion/SetObjectArrayElement) and the FaceData wire layout confirmed twice (Java mo.g0 + native serializer 0x179520): 1 float, 2 float, 3 float confidence, 4 Rect, 5 FacePose, 6 FaceLandmark, 7 original_rect, 8 Gender. KSJNILib.renderModel full GetFieldID list resolved; pixels are the byte[] argument; faces/param_info not read. updateModelOut output structs enumerated.",
    "Gap 3 - render/encode + threading/lifecycle + model fallback: FaceMagicController (WesterosGlProcessor) -> libfaceless-plugin (DT_NEEDED libykit+libFaceMagic) FMGlProcessor::OnDraw on GL thread; FMDataExchanger::setTransFaceData; encoder via MediaRecorderImpl native* in libdaenerys; setData vendor-flag gate f23915h; Java ResourceLoader.loadData model-byte path; Ycnn model missing callback; WESTEROS_EVENT_MODEL_MISSING.",
    "Gap 4 - deliverables: PIPELINE.md (9 sections), report.md section 9 + intro pointer, findings.json data_pipelines[3] (valid JSON, manual schema check), 8 new evidence files + cross-variant VideoFrame source, 4 new disassemblies, 12 decompiled classes indexed in sources/index.md."
  ],
  "remaining_unknowns": [
    "class that supplies com.kwai.camerasdk.video.VideoFrame at runtime in bulldog (no DEX definition)",
    "names of kuaishou MediaDataType 35/36/38",
    "names of FaceData float fields 1 and 2",
    "rotation arithmetic inside the stripped FaceDetectorContextInterface implementation",
    "queue depth / drop counters in the libdaenerys media graph"
  ],
  "notes": "No prior evidence deleted. All new jadx runs were single-class and serialized; Ghidra was not needed. findings.json validates with a manual schema check (jsonschema is not installed in the venv). Main should spot-check report.md section 9 anchors and PIPELINE.md length (385 lines)."
}