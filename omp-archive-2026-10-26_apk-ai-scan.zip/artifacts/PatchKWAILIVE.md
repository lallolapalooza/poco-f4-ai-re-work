{
  "status": "complete",
  "pipeline_file": "reports/kwai_live/PIPELINE.md",
  "pipelines": [
    "live_video_capture_effect_push",
    "live_audio_stannis_push",
    "live_effect_model_binding"
  ],
  "gaps_closed": [
    "gap1_video_capture_chain: LivePushActivity -> prepush presenter g -> CameraView -> Daenerys (libdaenerys.so, 138 JNI) -> CameraControllerImpl; capture defaults resolved from DaenerysConfigBuilder + obfuscated do.u field map (30fps, YUV output kCameraOutputDataTypeYuv=0, 720/1280 size pair, 44100/1ch/16bit); encoder tap = nativeSetMediaCallback(fps,maxW,maxH,downSample,cb) -> MediaCallback -> Arya.inputRawVideo -> nativeInputRawVideoByteBuffer (libkwaivoip.so); preview = separate EGL display pass (NativeRenderThread.nativeDrawFrame); FaceDetectorContext registered to both Daenerys.X() and Westeros.nativeSetFaceDetectorContext; FaceMagic runs as a Daenerys GlPreProcessor (onDraw(VideoFrame,int)) on the GL thread",
    "gap2_audio_chain: live audio = Arya.startLiveStream -> AryaAudioEngineProxyImp -> Stannis/libkwaiaudio.so (10ms frames, PCM16, byteLen=sr*ch*2/100; ch=2 live; enableAudioVad/AudioPreProcess true by default); AEC/NS/AGC, VAD (AudioVadInfoCollector 500ms hangover), voice-effect enums kVeo 0-15 / kReverb 0-18 / kPostEffect 0-5; VoiceDetect JNI 0x12a49c/0x12a56c returns {result_available, background_prob, speech_prob, music_prob}; A/V sync native via LiveStreamBgmOffsetCb + SpkVocalBgmSyncWorkshop; sample rate 44100 vs 48000 inconsistency documented as unknown",
    "gap3_model_binding: paths/packages only over JNI (nativeSetYlabModelPathConfig, nativeSetPath, FaceMagicController.nativeSetEffect(byte[],int,int)); live vs recorded difference = frame driver (Daenerys GL pipeline + YUV MediaCallback->Arya vs MediaRecorderImpl/MediaCodecEncoder surface input + bitmap YcnnPluginUtils.getFaceData); identical catalogue, 0 bundled models",
    "gap4_threading_lifecycle: push state machine INIT/READY/PUSH_SUCCESS/RETRYING/ERROR/PUSH_STOPPED, startPush gating, stopPush->Arya.stopLiveStream, retryWhen 2s bounded with fatal codes 1016013014/1016013015, background pause/foreground resume, QosInfo.getDroppedVideoFrames + VideoFrame.canDrop, Camera2->Camera1 one-shot fallback, GPUPerformance Level buckets 0/50/100/200/500, optional YCNN NPU backends absent from APK",
    "gap5_deliverables: PIPELINE.md (3 pipelines x 9 contract sections), report.md §11 appended, findings.json data_pipelines[] added and schema-validated, new sources under sources/classes/live/ (30 classes) + index.md update, evidence live_push_trace.md / live_cmd.txt / kwaiaudio_strings.txt, native libdaenerys.so.*, libaudioplugin.so.*, audio_voicedetect_interface.s, audio_voicedetect_process.s"
  ],
  "remaining_unknowns": [
    "live TX sample rate (44100 vs 48000) and the exact resampler chain for the live stream out",
    "enumeration/units of Arya VideoFrameAttribute.rotation and .csp (YUV matrix)",
    "which DaenerysConfigBuilder resolution slot (resolutionRequest.a/b/c) is preview vs encoder capture",
    "Arya video input queue depth and pre-encoder drop policy",
    "role of the westeros AudioPlugin bridge (libaudioplugin.so -> libksaudioprocesslib.so) in live; present in APK but no live call site found",
    "VAD/denoise model file names and formats (paths + MD5 only at runtime)",
    "AE2 effect-package format details (pre-existing)"
  ],
  "notes": "All work confined to reports/kwai_live/. findings.json validated with evidence/validate_findings.py -> 'VALID: findings.json conforms to SCHEMA.json (features=9 models=0 unknowns=13 status=runs_unverified)'. jadx used single-class only with --threads-count 2 and 2 parallel workers; no Ghidra import was needed for this patch (only capstone disassembly of two 100-500 byte JNI wrappers). Correction made during the patch: libaudioplugin.so IS in the APK (43,160 B, 2 JNI) and links libksaudioprocesslib.so + libdaenerys.so; it is documented as a separate audio bridge of unknown live relevance. Existing report/evidence files were preserved; only the new §11 was appended to report.md and new keys added to findings.json."
}