{
  "gaps_closed": [
    "Camera data path: front Camera2 ImageReader 640x480 format 35 (YUV_420_888) -> NV21 460800 B via com.miui.image.Yuv, stride=width, angle hard-coded 90 -> FaceOrientation.RIGHT(8), no frame timestamp, backlog-1 drop policy, ROI (auth always null, enroll rotated guide rect), no Java mirroring, device gates via resources arrays (munch in device_need_operating_mode only)",
    "JNI lifecycle with exact signatures/structs: all 25 FaceAuthNative exports decompiled (Ghidra 37/37), st_image_t/st_rect_t/st_detect_t/st_face_id_info_t/st_template_info_t layouts, field-ID offsets, buffer pinning via GetByteArrayElements, enroll returns faceId vs rc[0] status, auth faceIds=NULL, detect callback path (never enabled)",
    "Output consumption: status 0 -> onFaceAuthenticated -> transact 203 to SystemUI with constant face id 123456; acquired/error codes 202/204/205; liveness 0.9 and quality gates only in native; no fallback path inside the APK",
    "Threading/lifecycle: auth_worker + serv_worker HandlerThreads, 2 native detached threads (verify, liveness) + BlockingQueue/condition_variable, model load at st_auth_init, 3 s auth timeout, 5x camera retry with 200 ms backoff, 30 s enroll timeout, 60 s deferred release",
    "Template and matching: /data/data/com.miui.face/files/template_file.data, protobuf pb.TemplateFile magic STFACEUNLOCK v1.0.1, dot-product distance (Q16 2^-16 path) -> normalize_score_by_model -> stsdk::FeatureCmp::normalizeScore -> protector::NormModel::Run -> FeatureManager::Unlock vs DEFAULT_VERIFY_THRESHOLD 0.905f",
    "PIPELINE.md added with both pipelines (9 contract sections each); findings.json data_pipelines (auth, enroll) added and validated"
  ],
  "notes": "Artifacts: native/jni_all.c, native/api_prototypes.txt (.rodata 0x7520c0-0x752a80), native/jni_signatures.txt, 20 capstone disassemblies (big_*.s), evidence/resources_arrays.txt, evidence/manifest_strings.txt (sharedUserId android.uid.system, persistent=true), evidence/cmd_patch.txt, evidence/hashes.json (patch_2026_10_24). New sources: sources/faceunlock_extra/ (13 classes) and sources/index.md updated. report.md sections 11-15 appended; prior content untouched. Main agent should run json.load on findings.json/hashes.json, confirm reimpl/pipeline.py still runs, and spot-check rendering of the new report/PIPELINE tables.",
  "pipeline_file": "reports/miui_biometric/PIPELINE.md",
  "pipelines": [
    "auth",
    "enroll"
  ],
  "remaining_unknowns": [
    "metric (cosine vs other) and PCA projection per net - config inside encrypted meta.conf",
    "embedding dimension",
    "liveness multi-frame aggregation",
    "native input mirroring (Reverse layer present, prototxt encrypted)",
    "default template Identifier namespace",
    "per-net mean/scale constants"
  ],
  "status": "complete"
}