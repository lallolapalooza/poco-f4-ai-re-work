{
  "status": "complete",
  "pipeline_file": "reports/kwai_video/PIPELINE.md",
  "pipelines": [
    "camera_frame_to_face_detect",
    "ycnn_model_binding",
    "beauty_render_encode",
    "frame_threading_lifecycle"
  ],
  "gaps_closed": [
    "Gap 1 producer/format: camerakit.d$e.onImageAvailable (Camera2/ImageReader) -> videoCapture.i YUVFrameBufferReader decides yuv_format from plane pixelStride (NV21=2, NV12=1, I420=0, RGBA=3), de-strides to 1.5*w*h, then VideoFrame.fromCpuFrame(...,rotation,mirror)",
    "Gap 1 JNI: kuaishou::android::VideoRawFrameFromJni @0xece3c in libdaenerys.so reads VideoFrame fields via JNI; full signature table incl. nativeDetectFacesFromFrame(J,VideoFrame,I)[[B and nativeSetFaceDetectorContext(JJJI)V",
    "Gap 1 hand-off: FaceDetectorContext shares nativeContext+sensorManager with Westeros; FaceMagicController registered via FacelessPlugin/Westeros.applyPlugin",
    "Gap 2: path -> YCNNGetConfig2Model -> createModel/createModelPost -> YlabProvider CreateModel/setParamInfo with magic_ycnn_model_* keys; net_w/net_h in model header, normalisation is single scalar doNormalize(double)",
    "Gap 3: beauty processor classes in libwesteros.so, WesterosFBO output, Daenerys PreviewGlGroup/RecordGlGroup/EncoderGroup split, MediaCodecVideoEncoder handoff",
    "Gap 4: do.o0 FrameProcessThread enum (camera=1,cpu=2,gpu=3,encoder=4), RunloopProcessor/EasyFrameDropManager/FrameRateAdapter, FrameMonitor CSV keys, model-missing fallbacks",
    "Gap 5: PIPELINE.md (9 template sections + end-to-end trace), report.md section 9, findings.json data_pipelines[4], sources/native/evidence files"
  ],
  "remaining_unknowns": [
    "yuv_format -> YCNN KSY_COLOR_TYPE mapping inside native AndroidVideoFrame wrapper",
    "YCNN normalisation scalar / mean subtraction",
    "queue depth and drop thresholds per stage",
    "preview vs record: one shared GL pass or two",
    "landmark count/layout and net_w/net_h per model (need a .model file)"
  ],
  "notes": "libdaenerys.so (2.58 MB, sha256 3b0758bf...b146ee) and libwesteros.so were missing from the first extraction (90 MB cap); both pulled from the APK and analysed. New native dumps: native/libdaenerys.so.json (138 JNI), native/libwesteros.so.json (43 JNI), native/daenerys_videorawframe.s + .strings.txt (42 resolved JNI field literals), native/ylab_createmodel.s. New evidence: evidence/07_camera_jni_trace.md, 08_daenerys_westeros_strings.txt, 09_patch_cmds.txt; evidence/05_hashes.txt appended. 17 new decompiled classes in sources/classes plus a new section in sources/index.md. findings.json re-validated: all SCHEMA.json required keys present, valid JSON, 4 data_pipelines, 11 unknowns. Nothing from the previous report was deleted or rewritten; all additions are appends."
}