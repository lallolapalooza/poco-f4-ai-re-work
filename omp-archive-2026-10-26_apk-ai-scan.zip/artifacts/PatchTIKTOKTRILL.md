{
  "status": "complete",
  "pipeline_file": "reports/tiktok_trill/PIPELINE.md",
  "pipelines": [
    "face_frame_video",
    "face_attribute_age"
  ],
  "gaps_closed": [
    "Gap 1 (nativeProcessFrame ints): resolved as (input GL texture id, output GL texture id) — register-shuttle trace 0x2eac68/0xaf58d4/0xa9f91c plus the Java caller NaviGLSurfaceView.onDrawFrame (pc 514/578) and C36620EXe.LIZJ() texture creation; width/height are the last two ints, timestamp = System.nanoTime()/1e9 seconds, textures GL_TEXTURE_2D/RGBA8/GL_UNSIGNED_BYTE/GL_LINEAR, rotation and camera facing are one-shot setters (native inverts the facing flag at 0x2ead34).",
    "Gap 2 (preprocessing): letterbox resize algorithm recovered (0x9cf6d8 portrait / 0x9cf7ac landscape: short side -> net input size, aspect kept, other side rounded to the alignment field, scale cached at +0x34/+0x38); negative result proven that the two u8->f32 loops at 0x9a0100 and 0x9e4fb0 belong to GAN nets (FUN_0099f8b0 'up_0_bright_high', FUN_009e4a90 'LaughGanRet does not init.'), so the detector's own normalisation stays unknown; numeric net extent/alignment shown to come from runtime model info (net[+8]/net[+0xc]).",
    "Gap 3 (invocation): espresso::Thrustor per submodel with full PLT/call-site map (CreateNet 0x697ce8, SetInput 0x9a017c, Inference 0x697a90/0x9e50b8, Extract 0x697a60, getOutput 0x69e2d4, ReInferShape 0x6a5238, SkipLayer 0x696bb0), setThreads(4) at 0x9b2588, CADENCE RECOVERED: adaptive frame step 2 -> 4 -> interval/3 while no face (FS_DoPredict, counters at +0x1f0, interval +0x1e8) plus config keys skip_frame/base_skip_frames/framerate/face_detect_interval and bef_face_detect_ext_param_st{dectectIntervalTime,useFastModel,imageMode,maxFaceNum}.",
    "Gap 4 (output): VEFaceDetectInfo/ PVJ/PVI field order and counts documented (rect, score, 106 points + 106 visibility, yaw/pitch/roll, eyeDistance, faceID, action, trackCount; PVI eyes 22+22, brows 13+13, lips 64, iris 20+20), postprocess dequantise+index-permute (0x697ab4-0x697b88, table 0x12a2bf0) and 19/47-class 0.5/0.125 threshold helper (0x69f740-0x69f858), consumers X.EHf/X.EHg/La.LIZ/X.EHr and the shipped FaceReshape_V2/distortion landmark indices.",
    "Gap 5: PIPELINE.md written with all 9 contract sections; findings.json extended with data_pipelines (2 entries), updated frame-interface feature and 13 explicit unknowns; report.md section 11 added without deleting any prior evidence."
  ],
  "remaining_unknowns": [
    "Numeric detector net input extent and alignment value (algorithm confirmed, numbers read at runtime from model info)",
    "Detector u8->f32 normalisation (mean/scale) — no such loop in the recovered FS_DoPredict/0x9cf2d4/0x9cf6d8/0x9cf7ac path",
    "Record -> tensor/field attribution for pout, base120det, partface, eyecls, agenet (descriptor schema still unknown)",
    "Default values of dectectIntervalTime / skip_frame / framerate for this build (server-side AB and downloaded effect config)",
    "OES texture support at the VESDK recorder entry (native libttvesdk.so, outside the analysed AI assets)"
  ],
  "notes": "New artifacts: PIPELINE.md; evidence/frame_pipeline_native.md, beffectnative_callers.txt, thrustor_calls.txt (206 sites), thrustor_got_refs.txt, algorithm_xrefs.txt, tensor_name_xrefs.txt, callgraph_reach.txt, raw disassembly of the SetInput/Inference/prob sites; reusable scanners evidence/scripts/{xref_scan,calls_to,dex_callers,reach}.py; Ghidra outputs native/libeffect_{fs,smash,preprocess,detector,detect_infer}_decompiled.c with native/ghidra_scripts/DecompileAt.java (address-driven, needed because Ghidra imagebase is 0x100000); new sources/classes (NaviGLSurfaceView, C36620EXe, PVJ, X.PVI, FaceDetect, FaceDetectInfo, ViewControllerInterface, ModelnamesAssigner, RequirementResourceMapper/Define, TEEffectUtils) and an updated sources/index.md. findings.json re-validated with reimpl/validate_findings.py (VALID). Ghidra runs were serialised on logs/ghidra.lock with a 3 GB heap."
}