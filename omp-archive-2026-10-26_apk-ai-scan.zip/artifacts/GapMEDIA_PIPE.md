{
  "status": "complete",
  "stages": [
    "decode + EXIF orientation (PNG eXIf tag 0x0112=6, own PNG codec; EXIF transforms 1-8 implemented; decoded raster proven equal to the upright source)",
    "face quad: YCbCr skin-chroma box (stand-in for the two YOLO detector nets, whose head/anchor decode is not recovered) -> (139,204)-(374,486)",
    "landmarks: face_landmark_mb360_64.tflite, [1,64,64,1] f32 gray 0..255 (graph op0 SUB 127.5) -> [1,154] = 77 pts in 64x64 crop pixels -> image-space bbox",
    "parsing: Fprs.0003.Exp007e33_quan1_sm.tflite, [1,512,384,3] f32 RGB 0..255 (graph op0 QUANTIZE scale 1.0 zp -128) -> [1,512,384,15] softmax; crop built from the config mean_shape bbox fit; class map skin=1/hair=13/neck=14",
    "skin segmentation: skin_model_expand_supply_pta18000_quant_resizetrain_seg153.tflite, [1,320,320,3] f32 RGB 0..1 (op0 QUANTIZE 1/128 zp -1) -> [1,320,320,1]; threshold 0.6, keep_block_radio 0.01, connected-component drop",
    "mask -> image space: clamp(skin_mask + parsing skin ch1), parsed hair (ch13) zeroed, shader 0.3 alpha floor limited to the landmark quad",
    "effect: real skin_white LUT (512x512 RGBA = 8x8x64) with image_white_split_fs.glsl shader maths reimplemented in NumPy; out = mix(src, LUT(src), alpha*0.7)",
    "render/export: rendered.png + mask overlay + per-stage PNGs + stats.json; PASS assertions (shapes, softmax sum, input-dependent model outputs, delta finite)"
  ],
  "files": [
    "reports/miui_mediaeditor/reimpl/photo_pipeline.py",
    "reports/miui_mediaeditor/reimpl/GAP_CLOSURE.md",
    "reports/miui_mediaeditor/reimpl/GAP_CLOSURE_photo_pipeline.md",
    "reports/miui_mediaeditor/reimpl/coverage_fragment.json",
    "reports/miui_mediaeditor/reimpl/coverage_fragment_photo_pipeline.json",
    "reports/miui_mediaeditor/reimpl/README.md",
    "reports/miui_mediaeditor/evidence/photo_pipeline/verify.txt",
    "reports/miui_mediaeditor/evidence/photo_pipeline/stats.json",
    "reports/miui_mediaeditor/evidence/photo_pipeline/source_exif.png",
    "reports/miui_mediaeditor/evidence/photo_pipeline/decoded_upright.png",
    "reports/miui_mediaeditor/evidence/photo_pipeline/face_crop_landmark64.png",
    "reports/miui_mediaeditor/evidence/photo_pipeline/landmarks.png",
    "reports/miui_mediaeditor/evidence/photo_pipeline/parsing_crop_384x512.png",
    "reports/miui_mediaeditor/evidence/photo_pipeline/parsing_labels.png",
    "reports/miui_mediaeditor/evidence/photo_pipeline/mask_skin.png",
    "reports/miui_mediaeditor/evidence/photo_pipeline/rendered.png",
    "reports/miui_mediaeditor/evidence/photo_pipeline/rendered_mask_overlay.png"
  ],
  "notes": "photo_pipeline.py runs end-to-end on a 512x512 synthetic portrait and exits 0 (`RESULT: PASS`, ~4 s) writing evidence/photo_pipeline/rendered.png. Inference uses the shipped .tflite flatbuffers through ai_edge_litert (the kernels FuAI vendors) with the extracted real weights (SHA-256 recorded in verify.txt/stats.json); no encrypted prologue entry and no JAX placeholder is used. Per-stage numbers: landmarks [1,64,64,1] 19.3..246.0 -> [1,154] 3.48..55.38; parsing [1,512,384,3] 14..248 -> [1,512,384,15] sums 0.988..1.008 (argmax background 193079, skin 2011, nose 707, l_eye 341, r_eye 470); skin [1,320,320,3] 0.067..0.973 -> [1,320,320,1] 0.000..0.996, 26.6% coverage after threshold+CC; alpha mean 0.560 over 58520 px (22.3%), luma 0.5737 -> 0.6125 (+0.0388). Input normalisation is derived from each graph's first op, resolving PIPELINE.md §3.5's 'unknown': gray 0..255 (mb360 SUB 127.5), RGB 0..255 (Fprs QUANTIZE 1.0/-128), RGB 0..1 (skin QUANTIZE 1/128/-1); RGB vs BGR was checked empirically (skin peak 0.633 vs 0.113). Parsing channel semantics are CONFIRMED from image_choose_whole_white_skin_fs.glsl (background=0, skin=1, ... hair=13, ... neck=17 -> channel 14 via cate_mask_order=[0..13,0,0,0,14,0]); the label-texture path itself is inferred. GAP_CLOSURE.md states the exact 7 stages, the confirmed-vs-inferred table (LUT->uniform binding, mean_shape frame 384x512 vs 512x512 ambiguity, mb360 77pt <-> mean_shape 75pt correspondence missing, tex_face_rate_mask GL pass missing), and the exact omissions: DNN detector decode (classical box stand-in), UV-mesh mask warp, even-skin/flaw/del-spot/teeth/makeup/reshape GL stack, inpaint, video path, 5 encrypted TFLite. Mapping to FaceBeautyRenderFragment/fuImageBeautyPreProcess/Preview/GetResultBitmap is tabulated. Note: the synthetic cartoon is deliberately out of domain for FuAI, so the parser labels only the eye/nose band and the skin mask is noisy; the docs say this is input quality, not a wrapper limitation, and no production-quality mask is claimed. Coordination: peer GapMEDIA_TFLITE appended its model-runner section to the canonical GAP_CLOSURE.md (my content intact) and will merge coverage_fragment.json; identical timestamped backups of my versions exist as GAP_CLOSURE_photo_pipeline.md / coverage_fragment_photo_pipeline.json. README.md has a new section 5. Verification to re-run if desired: `$PY reports/miui_mediaeditor/reimpl/photo_pipeline.py` (exit 0, ~4 s)."
}