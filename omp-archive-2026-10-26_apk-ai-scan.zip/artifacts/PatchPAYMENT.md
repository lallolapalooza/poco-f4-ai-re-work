{
  "status": "complete",
  "pipeline_file": "reports/miui_paymentservice/PIPELINE.md",
  "pipelines": [
    "ocr_digit_capture"
  ],
  "gaps_closed": [
    "UI/camera path: VoucherFragment.j0 -> EntryManager.a(f.Y1='mibi.ocr', Fragment, bundle, 31) -> DigitOcrEntry -> CaptureActivity/CaptureFragment -> a.b.a.c mask (350x65dp centred; portrait x*=previewH/screenW, y*=previewW/screenH; landscape plain scale; applied after bitmap rotation) -> a.b.a.b Camera1 one-shot NV21 (Y plane only, size = supported size closest to screen aspect) -> a.b.a.f HandlerThread 'decode' (1 frame in flight, 300 ms re-arm, drop-and-request-next) -> a.b.a.d (Y*0x10101|0xFF000000, rotate cameraMode=(450-rotation)%360, crop, RGBA direct ByteBuffer)",
    "JNI contract: all 11 shipped exports disassembled with addresses/signatures; buffer is GetDirectBufferAddress borrowed pointer (no copy/global ref), synchronous setImage->recogDigit on the decode thread; nativeBeginProcess returns true unconditionally; nativegetwordConfidences returns an unfilled zero array; nativeEndProcess is not exported for this class (legacy class only) => XiaoMIDigitOCR.b() dead code and native MainOCR leaks",
    "output consumption: gate meanConf(+0xe20)>80 && count in whitelist -> CaptureFragment.h(str) into R.id.result, preview paused; confirm writes fragment result under '2131362538' (R.id.voucher_edit) -> VoucherFragment setText + setMaxLength(n), submit validates m<=len<=n else Toast mibi_voucher_error_password; failure paths incl. camera open failure, missing models, out-of-bounds crop, dead endProcess enumerated",
    "privacy: no frame or digit persistence in this path (only LIBSVM models copied to app-private filesDir; native D:\\123.txt model dump and 'ocrdebug len=%d' log only)",
    "PIPELINE.md written with exact coordinate transforms, preprocessing order and the already recovered HOG/SVM contract; findings.json data_pipelines[] added and validated against SCHEMA.json"
  ],
  "remaining_unknowns": [
    "adaptiveThreshold window/offset and rgbToGray coefficients (segmentation stage, pre-existing)",
    "whether MainOCR+0xe20 is an average or minimum confidence (JNI name says mean; estimateFrameMinConf/AvgConf both write neighbouring per-frame struct fields)",
    "exact result-selection path when MainOCR+0xe40 == 0: process_OneImg calls estimateBestResult (sole call site 0x2c8dc) only when +0xe40 != 0, yet the harness produced digits=4 with +0xe40 = 0, so another (computed-base) writer of +0xaf8 is possible and is not resolved",
    "binary gate model label semantics"
  ],
  "notes": "Files: new PIPELINE.md; report.md gained section 9 'UI -> frame -> JNI -> result contract' (old deliverables map renumbered to 10) plus updated deliverables rows; findings.json gained data_pipelines[0] (schema validation: VALID); sources/consumer/ holds 9 jadx --single-class decompilations (VoucherFragment, CameraIntentData+creator, entry.a, IEntry, o.h/o.l, l.c/l.f, v0/h0) and sources/index.md documents them; evidence/ui_jni/ holds jni_disasm.txt (JNI + accessor disassembly), result_field_writers.txt (full .text scan of writers of +0xaf8/+0xe1c/+0xe20/+0xe24/+0xe38..0xe40 and the sole estimateBestResult call site), exported_jni_symbols.txt (nm -D), xref.txt (bytecode xref finding VoucherFragment.j0), resources.txt (ARSC/layout dump), cmds.txt and the two probe scripts. Existing report content and evidence untouched; no APK writes. JSON validated with python -m json.tool and evidence/validate_findings.py."
}