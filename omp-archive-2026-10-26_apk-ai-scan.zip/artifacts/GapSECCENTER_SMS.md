{
  "status": "complete",
  "files": [
    "reports/miui_securitycenter/reimpl/pipeline_sms.py",
    "reports/miui_securitycenter/reimpl/GAP_CLOSURE.md",
    "reports/miui_securitycenter/reimpl/coverage_fragment.json",
    "reports/miui_securitycenter/reimpl/verify.txt",
    "reports/miui_securitycenter/reimpl/README.md"
  ],
  "cases": [
    "$PY reimpl/pipeline_sms.py --selftest -> exit 0, 45/45 checks",
    "$PY reimpl/pipeline_sms.py --demo -> exit 0, verdicts [2,2,0,0] (2 spam blocked block_type=4, 2 ham allowed)",
    "$PY reimpl/pipeline_sms.py --sender 10086 --body '【中国移动】您本月话费余额为120元' --json -> exit 0, verdict 0, pattern_word 0x1000, thresholds shifted 29.81/10.10",
    "spam: 京东 prize/loan/link SMS -> stage 0 d=+10.244 > thr0=10.100 -> verdict 2 / should_filter 2 / block_type 4",
    "spam: 免息贷款 link SMS -> votes stages 0-2, blocks at stage 3 d=+5.744 > thr0=5.208 -> verdict 2",
    "ham: 晚上七点老地方见，别迟到 -> pattern bit0 (sms_body_length) hard allow, verdict 0",
    "ham: 会议改到下午三点，材料已经发你邮箱了 -> stage 0 d=-13.962 < thr1 after all_chinese shift, verdict 0"
  ],
  "notes": "Ported end-to-end P1 path from the jadx sources into reimpl/pipeline_sms.py: ah.b/dh.a.d sender (+86 strip, 8 categories), ah.h.c/ah.h.a body normaliser incl. de-obfuscation, dh.j/dh.b/dh.c rule stages (9 rule features), dh.e.e/dh.e.a pieces + token collection, bh.a.h dict loader (header + 4 char-class tables + 348982-word table via ir/parse_dict.py), bh.a.c DAG Viterbi segmentation + bh.a.b char-class state machine + bh.a.d/f lookups, ah.i.b URL bit, ch.a/ch.b/ch.c/ch.d/ch.e pattern features over models/assets_pattern (lenient org.json parse: bare keys + 0x ints), ah.e.g threshold shift, ah.d.h cascade via reimpl/model.py (load_stages/init_params/build_masks/stage_scores), ah.a.a verdict -> j2.a.h shouldFilter -> SmartSmsFilterPolicy block type. Two previously-open constants resolved from the APK dex by single-class jadx instead of guessed: com.google.android.exoplayer2.C.BUFFER_FLAG_FIRST_SAMPLE = 0x08000000 and miuix MenuBuilder.USER_MASK = 0xFFFF. Fidelity details: Java String.length (UTF-16 code units) used for every length test, feature/pattern matching done on a code-unit copy of the body, Java Pattern ASCII-only \\d/\\w/\\s reproduced with re.ASCII, float-division rounding in bh.a.c reproduced with np.float32, dh.f's 'drop 1-char tail' quirk kept, j2.a.h's catch(Exception)->allow reproduced. Verified all four messages against model.classify_numpy (agreement <1e-6 per stage, same verdict) and that bh.a.c output is an exact partition of the input. INFERRED and documented in GAP_CLOSURE.md: dh.c.i's non-separator length chain is a jadx 'code duplicated' region where every assignment collapsed to -1, so unseparated digit runs get no rule type and BankCard is unreachable; ch.b num_types read as 'no match -> false'; sender normaliser o2.f.p/o2.f.I not reimplemented; ah.f.a history guard stubbed inactive; assets/phish absent so phish bit/verdict 1 unreachable; astral chars differ from Java in segmentation/ordering only. P2 (1.bin/2.bin), P3, P4 untouched. verify.txt keeps the pre-existing model.py section and appends selftest/demo/json runs with commands and pass/fail; verify.txt, GAP_CLOSURE.md and coverage_fragment.json are the parent's merge inputs (REIMPL_COVERAGE.json entry now 'complete' for P1, with the dh.c caveat)."
}