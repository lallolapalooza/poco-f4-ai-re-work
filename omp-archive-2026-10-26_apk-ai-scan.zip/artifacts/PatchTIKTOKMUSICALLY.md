{
  "status": "complete",
  "pipeline_file": "tiktok_musically/PIPELINE.md",
  "pipelines": [
    "vesdk_render_to_face_dnn",
    "face_attribute_age"
  ],
  "gaps_closed": [
    "Verified libeffect.so (dad4778a…e76c35), libttvesdk.so (e38abe25…a6ce74) and all three face bundles are byte-identical between musically and trill, so the frame path is shared (evidence/hashes.txt, evidence/video_interface.md §0).",
    "Decompiled the video classes from THIS APK: BEFEffectNative, VEFaceDetectInfo, X.C64698PZc, X.C64697PZb, VEFaceAttribute, VEFaceAttributeInfo, medialib FaceDetect/FaceDetectInfo/FaceAttribute (sources/video/).",
    "Reproduced the frame path: nativeProcessFrame 0x2eac68 → bef_effect_set_width_height → bef_effect_process_texture (0x3097f0 → _with_loading_timeout 0x3097f8), with disassembly saved in native/libeffect_musically_*.s.",
    "Resolved the first-two-int semantics left unknown by trill: Java arg2/arg3 are forwarded in order as process_texture args 2/3 (thunks 0xaf58d4 'mov w19,w4;mov w20,w3;ret' and 0xa9f91c 'mov x0,x21;mov w1,w20;mov w2,w19;ret'); args 4/5 are width/height, arg 6 the double timestamp. The meaning of forwarded arg2 remains unread by the wrapper (documented as unknown).",
    "Confirmed texture format: GL_TEXTURE_2D / RGBA8888 / UNSIGNED_BYTE via glTexImage2D(0xde1,0x1908,…,0x1401) in libttvesdk 0x4b7314–0x4b7330; every face/expression task rejects YUV and GRAY (strings 0xd02ab1, 0xd02adf, 0xd25120).",
    "Confirmed rotation and camera facing are separate setters: nativeSetFrameOrientation → bef_effect_set_frame_device_orientation, nativeSetCameraPosition → bef_effect_set_camera_device_position with the Java boolean inverted (cset w1,eq).",
    "Located the real per-frame path: the app uses libttvesdk.so's DrawFrame render function (0x1cf4f0–0x1cfa60), which links libeffect.so directly; no Java class calls BEFEffectNative.processFrame in musically or trill (dex_find result saved).",
    "Recovered the full VEFaceDetectInfo field mapping (rect, score, PointF[106], float[106] visibility, yaw/pitch/roll/eyeDistance, faceID/action/trackCount, ext iris/eye/lip/eyebrow with mask bits 1/2/4/8) and the 22-field VEFaceAttribute parcel order (age first, matching the shipped agenet model).",
    "Documented variant-specific differences: only the Java obfuscation map differs (PVJ/PVI/C36340EMk/C36453EQt vs C64698PZc/C64697PZb/C34719DjF/C7Q2, Covode index 115413 vs 115417); native code and models identical.",
    "Corrected report §6: the claimed bgr448 age-model crop assert does not exist in this libeffect.so; age-model input size is unknown.",
    "Added PIPELINE.md (9 sections), report.md §11, findings.json data_pipelines (2 entries, 6 features, 11 unknowns) and validated the JSON (evidence/findings_validation.txt)."
  ],
  "remaining_unknowns": [
    "Meaning of the 3rd int of BEFEffectNative.processFrame (forwarded to bef_effect_process_texture but never read by its body).",
    "Clock origin of the per-frame double timestamp (frame PTS seconds assumed; getter not identified).",
    "Detector input crop/resize and normalisation constants: base120 suggests 120×120 but the descriptor schema is still unparsed; the 'mean' record is anchor geometry, not image means.",
    "Age-model crop size (the bgr448 claim is not corroborated).",
    "Detector NMS/thresholds, landmark coordinate transform back to source space, and temporal smoothing in the native tracker.",
    "Java consumer classes of VEFaceDetectInfo.covert() (only classes8.dex and classes10.dex reference it; names obfuscated).",
    "Smash-face payload descriptor schema still blocks weight extraction and true tensor shapes (inherited blocker)."
  ],
  "notes": "Report patched, nothing removed: PIPELINE.md added, report.md §11 appended, findings.json gained data_pipelines + a 6th feature, evidence/video_interface.md, evidence/vesdk_drawframe_callsites.txt, evidence/libeffect_face_video_strings.txt, evidence/libeffect_video_exports.txt, evidence/{xref_scan,update_findings}.py, evidence/findings_validation.txt, native/libeffect_musically_*.s (5 files) and sources/video/ (9 classes + index.md) created; hashes.txt and cmd.txt extended. Helper scripts kept under evidence/ as reproducible artifacts. Report dir is 37 MB (includes copies of libeffect.so and libttvesdk.so for the xref evidence). Verification for the main agent: re-run `evidence/xref_scan.py native/libttvesdk.so --sym bef_effect_process_texture` and `python evidence/update_findings.py`."
}