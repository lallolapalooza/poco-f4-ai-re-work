{
  "status": "complete",
  "bundle_format": "magic f35b0612 + 8B header + 16B IV + 1040B keyed ciphertext (offset 28..1068) + verbatim tail; whole output XOR single byte k = b[4]^b[5]^b[6]; payload is a ZIP of DEFLATE entries (TFLite / GLSL / PNG / config.json). Decoded by reimpl/unbundle.py.",
  "decrypted": true,
  "jax_models": [
    "assets/tflite_langid.tflite.jpg -> reimpl/model.py + langid_pipeline.py (NGramHash MurmurHash64A + KmeansEmbeddingLookup + 3 hybrid FC + softmax; JAX vs NumPy max|d|=1.31e-06, 27/28 languages)",
    "bundles/face_landmark_mb360_64 (ai_face_processor_detect_landmark) PASS 1.53e-05",
    "bundles/s1 (91 landmarks + score) PASS 1.91e-05",
    "bundles/head (FC 126->14) PASS 2.09e-07",
    "bundles/facecheck40_dense_2000000_regress PASS 0",
    "bundles/hair_1209a_acnenet_crop0.1pos0.1_3x24x24_quat PASS 0",
    "bundles/mole_seg_24x24x3_1206_quat PASS 3.76e-06",
    "bundles/Fprs.0003.Exp007e33_quan1_sm FAIL 1.76e-01 (quantized-graph emulation)"
  ],
  "unknowns": [
    "U1 _obfuscation_key value: never written in libCNamaSDK.so (7 GOT-relative reads, empty-string static init) -> 48 of 726 bundle entries lost (3 config.json + acne_mole, age_gender160_0422, bindi_seg_tiny, Bdycntr, MOBILEONE_S2)",
    "U2 VerifySignature (0x5707e4) digest scheme and the 64-byte ZIP EOCD comment content",
    "U3 editor plugin com.miui.mediaeditor.algo.* absent from the APK, so app-level controller orchestration is only known via the FaceUnity SDK classes",
    "U4 inpaint (libvis NNF), libaiedit (MNN) and motion-photo (MACE) weights are external files",
    "U5 which TFLite delegate (GPU/Hexagon/XNNPACK) is used per device",
    "U6 why the Fprs face-parsing JAX conversion drifts (1.76e-01)"
  ],
  "notes": "Ghidra job bg_64 finished before cancellation; its output native/cnamasdk_bundle.c (93,927 B) is on disk and already referenced in report.md section 3.1 (BundleHelper::DecryptObfuscatedPackage pseudocode confirming the header/IV/XOR layout). Deliverables in $WS/reports/miui_mediaeditor (11.7 MB): report.md, findings.json (validated against SCHEMA.json with jsonschema 4.26.0: 7 features, 56 models), sources/ (11 jadx classes + index.md), native/, models/ (2.9 MB), ir/, reimpl/ (verify.txt PASS), evidence/. Bundle proof: 726 ZIP entries across 22 .bundle files, 678 extracted with matching CRC32, 0 mismatches. 33 TFLite models carved; every one has an I/O contract and feature mapping. Checks for main: jsonschema validation of findings.json and `python reimpl/verify.py` (expect RESULT: PASS, exit 0)."
}