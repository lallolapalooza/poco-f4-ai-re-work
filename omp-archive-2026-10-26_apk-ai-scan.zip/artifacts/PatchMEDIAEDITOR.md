{
  "status": "complete",
  "pipeline_file": "reports/miui_mediaeditor/PIPELINE.md",
  "pipelines": [
    "editor_photo_face_beauty",
    "editor_video_beauty",
    "editor_photo_makeup",
    "editor_photo_inpaint"
  ],
  "gaps_closed": [
    "Gap 1 (editor data path): full photo chain decoded — Bitmap/NV21 transport (FU_FORMAT_BITMAP=999 / FU_FORMAT_NV21_BUFFER=2, even-padded w/h, stride=width, V-at-even/U-at-odd NV21 packing), EXIF rotation, fuImageBeautyConvertRGBA2NV21WithBitmap -> fuImageBeautyPreProcess -> fuImageBeautyPreview -> fuImageBeautyGetResultBitmap, with 18 exact JNI symbols+addresses and Java descriptors (PIPELINE §2.4). Video: AMediaCodec + bundled libhevc decode in libMiVideoSDK.so, FrameRetriever JNI, BeautyWapper::render per frame.",
    "Gap 2 (per-model I/O in app): bundle->net mapping table for 11 bundles / 33 nets driven by each bundle's config.json; FuAI type ids; session params (threads, XNNPACK, GPU + model tokens, DSP); crop/align via mean_shape 75-pt fits (512x512 / 384x384 / 512x512), netin expand ratios, landmark subsets (teeth kps75 46..63, bindi 28 ids); output mask/landmark/score shapes; coordinate mapping via 80-vertex UV mesh + FUAI_*Warp accessors + image_face_data JSON.",
    "Gap 3 (postprocess/render): mask decode tables (cate_mask_order, mask_threshold 0.6, del-spot constants), 540x960 uint8 mask priors with 12-byte {w,h,c} header, 283-vertex/528-tri warp mesh with 99/245 offset vectors, RGBA8 displacement-map decode formula from image_chin_warp_fs.glsl, alpha-blend shader chain, makeup layer contract (makeup_config.json + script.js duktape + 8-12 PNG layers), inpaint NNF contract, and save path gltexturerender.c -> CacheData -> BeautyExportDataResult -> Bitmap.copy(ARGB_8888).",
    "Gap 4 (lifecycle/threading): BeautyBaseManager init/release, FURenderKit.h model install + fuProcessorChangeModel(1), HandlerThread/FURenderBridge action queues/single-thread save executor, RENDERMODE_WHEN_DIRTY (no per-frame loop), fuIsAIModelLoaded short-circuit, 10001/10002 error callbacks, dynamic-feature library ids, FU_IMAGE_BEAUTY_STATUS_* codes, video dlopen failure path.",
    "Gap 5 (deliverables): PIPELINE.md (9 template sections + end-to-end trace §0), findings.json data_pipelines[4], report.md §10, 47 new jadx single-class sources + index, 5 new evidence files, native/libMiVideoSDK.elf.{txt,json}, 7 new model-side artefacts (makeup config/script, face_warp mesh, mask mapper, 2 mask .data, warp shader).",
    "Correction: prior U3 was wrong — com.miui.mediaeditor.algo.* IS in the APK (2,664 classes); only the FaceUnity SDK layer is obfuscated (j2.c/j2.d/k2.a/f2.b/m2.a/gltexturerender.d). U3 rewritten in findings.json; U7-U10 added for genuinely missing pieces."
  ],
  "remaining_unknowns": [
    "U1 bundle 1024-byte prologue key (unchanged) — still hides 5 model files and 3 config.json",
    "U7 no Java selector for makeup/item_bundle/<style>.bundle in either dex (only image_threed/image_red* sliders are wired)",
    "U8 no in-APK caller of XmsContext.setupBeauty (video beauty wiring lives in the host app)",
    "U9 float input normalization constants for FuAI parser/skin/teeth nets (no mean/std in config.json; libfuai exposes mean_stddev_normalization)",
    "U10 runtime GPU-vs-CPU delegate selection per device"
  ],
  "notes": "Acceptance met: one photo edit traced UI (FaceBeautyRenderFragment/FaceBeautyViewModel) -> Fprs.0003.Exp007e33_quan1_sm.tflite ([1,512,384,3] f32 -> [1,512,384,15]) -> rendered texture -> fuImageBeautyGetResultBitmap -> CacheData -> BeautyExportDataResult Bitmap -> editor save (17-step table with class/method/JNI refs). Tensor binding documented: Java binds only image buffers (fuImageBeautyPreProcess/Preview/GetResult*, fuRenderImg); per-tensor binding is inside libfuai via config.json netin_/netout_/mean_shape blocks. findings.json validated with jsonschema against SCHEMA.json (VALID); all data_pipelines evidence paths verified to exist. Verification I ran: JSON schema validation, evidence-path existence check, descriptor/JNI-symbol cross-checks, mask header/byte-size arithmetic. Not run (out of scope for a docs patch): builds/tests (none in repo), reimpl/verify.py (prior pass unchanged), Ghidra (not needed; symbol tables were sufficient). No files outside reports/miui_mediaeditor were modified; APK untouched; /tmp scratch only."
}