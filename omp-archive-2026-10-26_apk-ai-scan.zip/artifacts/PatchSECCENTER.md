{
  "status": "complete",
  "pipeline_file": "reports/miui_securitycenter/PIPELINE.md",
  "pipelines": [
    "P1-sms-legacy-model (assets/model 5-stage log-linear cascade)",
    "P2-sms-tflite-new-engine (downloaded 1.bin/2.bin/v.txt)",
    "P3-sms-resource-download (api.sec.intl.miui.com resource.zip -> files/SmsEngineResource)",
    "P4-sms-url-cloud-check (GuardProvider IURLScanServer + signed cloud URL category)",
    "P5-ai-subtitles-delegated (com.xiaomi.aiasst.vision AiTranslateService)",
    "P6-ultraclear-delegated (persist.vendor.vcb.enable)",
    "P7-beauty-privacy-delegated (persist.vendor.vcf.* / facetracker + IGameBoosterWindow)"
  ],
  "gaps_closed": [
    "Gap 1: traced one SMS end-to-end. Real in-APK entry found: exported ContentProvider com.miui.antispam.db.AntiSpamProvider query/update case 9 (content://antispam/sms_judge, selectionArgs {address, body, simId}) -> c(String[]) -> new j2.c -> d2.b.e (PolicyManager, 20 policies) -> SmartSmsFilterPolicy.handleData/shouldFilter -> j2.a.h -> ah.a.a -> ah.d.h; verdict 1/2/0 maps to blockType 8/4, returned as MatrixCursor{smsBlockType} and logged async to ExtraTelephony.FirewallLog by o2.f.a. Corrected report §6 (AntiSpamService was wrong; it only does cloud phone-list updates) and documented exact data structures j2.c -> ah.b (int[9] rules, pieces, token List/Set, flag word) -> per-stage feature vector.",
    "Gap 1: PDU->text is outside the APK (no SmsReceiver defined; 'sms_judge' string only in AntiSpamProvider.<clinit>; pdus/createFromPdu only in networkassistant TelephonyUtil) - stated as unknown boundary with the confirmed 3-arg provider contract.",
    "Gap 2: model plumbing documented: ah.c.b is the only opener, prefers files/<name> over assets when f518c==false, no caching; l2.a calls ah.c.c(true) after install. Per-SMS full re-parse of assets/dict once (ah.d.k) and assets/model from offset 0; d9.a singleton is released (d9.a.a) in every exit path of j2.a.h so TFLite models/v.txt are re-opened per message. Resource init is the only async path (single-thread executor + AsyncTask). Failure paths: fail-open (0) in j2.a.h, policy disabled on IS_INTERNATIONAL_BUILD, legacy engine authoritative when com.android.mms versionCode < 11000249.",
    "Gap 3: new engine exact path: c9.a.a strips whitespace/quotes, lowercases, UTF-8 lead-byte split, v.txt TSV token->float appended in order with unknown tokens dropped and zero-pad to float[1][128]; a9.a (2.bin) score>0.6 'important', a9.c (1.bin) score>0.4 'unlawful', no activation in Java; a9.b/b9.b add 7 hard-coded regex rules keyed 10086/95555/'0'. Interpreter = NativeInterpreterWrapperExperimental(path,null), CPU, no NNAPI/XNNPACK. Download: GetResourceZipFile (ver 2.1.2, signed) -> DownloadManager -> MD5 6206c9f17a64246498b52e117d0cff1e -> files/resource.zip -> initSmsEngine -> unzip (zip-slip+size guarded) -> files/SmsEngineResource. Model internals marked unknown.",
    "Gap 4: delegated boundaries made explicit: AI subtitles = explicit startService to com.xiaomi.aiasst.vision/.control.translation.AiTranslateService with Bundle{from=channel, floatingWindowType=startAiSubtitlesWindow[, extra=close]} and state via content://com.xiaomi.aiasst.vision/subtitleState|screenTranslateState; UltraClear = persist.vendor.vcb.enable; beauty/privacy/portrait/pickup = persist.vendor.vcf.* + persist.vendor.camera.facetracker.* plus IGameBoosterWindow/DockWindowManagerService overlay. No pixel/audio/text payload crosses the boundary.",
    "Gap 5: wrote PIPELINE.md with all 9 template sections, a per-model matrix (source/transport/preprocess/invoke/postprocess/consumer) and P1..P7 tables with confidence tags and class/method/file evidence; added findings.json data_pipelines (7 entries, schema-valid), report.md §11 (11.1-11.7), updated sources/index.md, saved 20 new single-class decompilations and 6 new xref JSONL files plus native/tflite_run_jni.s."
  ],
  "remaining_unknowns": [
    "Exact caller SMS app code that decodes the PDU and calls content://antispam/sms_judge (outside APK); its quarantine logic is not observable here.",
    "Contents/graph/op set/dtypes of downloaded 1.bin and 2.bin, and the token->float semantics of v.txt (no network; not in APK).",
    "assets/phish content (absent from APK).",
    "Whether 1.bin/2.bin outputs are probabilities or logits (Java applies no activation).",
    "Literal value of com.google.android.exoplayer2.C.BUFFER_FLAG_FIRST_SAMPLE early-exit bit used by ah.e.b (constant name only)."
  ],
  "notes": "Findings preserved and extended, no prior evidence deleted. Validation: python jsonschema against SCHEMA.json passes (data_pipelines=7, unknowns=7). New source files under reports/miui_securitycenter/sources/classes (canonical copy; sources2..sources7 hold the raw jadx runs). Checks main agent may run: python3 -c \"import json,jsonschema;jsonschema.validate(json.load(open('findings.json')),json.load(open('../../SCHEMA.json')))\" and cd reimpl && python model.py ../models/assets_model (unchanged, exit 0)."
}