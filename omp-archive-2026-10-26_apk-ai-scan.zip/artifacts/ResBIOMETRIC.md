{
  "status": "complete",
  "stages": [
    "preprocess: NV21 (CvPixelFormat=3) -> colour convert -> rotate by FaceOrientation bitmask (UP=1,LEFT=2,DOWN=4,RIGHT=8) -> ROI (st_auth_set_roi/setDetectArea) -> resize -> per-net mean/scale",
    "face detection: Hunter RPN detector, square-padded 360 input (M_Hunter_CommonFace_Gray_ppl_360_9_2_5_v2_origin)",
    "tracking: stfaceunlock::NormalTrack / TrackManager (compact occlusion)",
    "alignment: 106 landmarks + occlusion (M_Align_occlusion_106_1_19_3 and _106_360_1_7_1)",
    "pose: ANN regressor yaw/pitch/roll from 106 pts (M_Align_CalcPose_Ann_106_2_3_0)",
    "eye state: open/closed per eye (M_Align_Deepface_Eye_State_Analysis_3_7_8)",
    "quality gate: MTNet attributes (M_Attribute_MTNet_Quality_1_0_0)",
    "liveness/anti-spoof: full-frame RGB CNN (IM_RGB_Liveness_General_Full_FP32_10_1_65), thresholds 0.9",
    "embedding: MobileNetV2-T6 on 112x112 aligned crop (M_Verify_MobileNetV2T6_Common_3_135_0)",
    "matching: cosine vs enrolled template (FeatureCmp, optional PCA/score-norm), DEFAULT_VERIFY_THRESHOLD=0.905, status 201=unlock",
    "template storage: pb::TemplateFile protobuf, magic STFACEUNLOCK v1.0.1, /data/data/com.miui.face/files/template_file.data"
  ],
  "models_extracted": [
    "M_Hunter_CommonFace_Gray_ppl_360_9_2_5_v2_origin (983313 B, sha256 ed96a7464716...)",
    "M_Align_occlusion_106_1_19_3 (1782033 B, 9b1a676565ca...)",
    "M_Align_occlusion_106_360_1_7_1 (2058513 B, 5f4fdb84262b...)",
    "M_Align_CalcPose_Ann_106_2_3_0 (123153 B, c8daf5eae905...)",
    "M_Align_Deepface_Eye_State_Analysis_3_7_8 (1771793 B, e1d020a71d63...)",
    "M_Attribute_MTNet_Quality_1_0_0 (471313 B, 50f64eb5abfc...)",
    "IM_RGB_Liveness_General_Full_FP32_10_1_65_half_compression_v2_origin (4106513 B, 69366df2ae8c...)",
    "M_Verify_MobileNetV2T6_Common_3_135_0_half_compression_v2_origin (5110033 B, 518b214184ad...)"
  ],
  "jax_status": "architecture_only: reports/miui_biometric/reimpl/pipeline.py runs (exit 0, verify.txt) on 112x112x3 synthetic face-like input, printing stage shapes boxes[196,4]/landmarks[1,106,2]/pose[1,3]/eye[1,2]/quality[1]/liveness[1]/embedding[1,512]; weights are random because all 8 model payloads are encrypted (STEF/v3: plaintext 16-byte header 'STEF'+u32 size+'VER'+v3+flags, then encrypted payload (entropy 7.997-8.000, no zlib/lzma/bz2/gzip/deflate, no repeating-XOR period, known-plaintext tar 'ustar' test fails), then 257-byte trailer; decrypted payload is a tar (meta.conf = st_model.ModelMeta protobuf, model.bin, rel.prototxt) per protector::TarModelResource; key derived at runtime by SenseTime protector sdk_protector_* AES/RC4/RSA/MD5 licence chain, not present in plaintext).",
  "unknowns": [
    "CNN weights (encrypted STEF payloads; requires reimplementing protector licence->key derivation)",
    "per-net preprocessing mean/scale and crop affine (inside encrypted meta.conf)",
    "detection and quality thresholds (runtime-set, no plaintext constants)",
    "per-ISO-3166 threshold table used by st_auth_set_threshold_by_international_code",
    "liveness ensemble composition (V7..V20/antispoof symbols exist, only one liveness blob shipped)",
    "embedding dimension (512 inferred) and whether FeatureCmp applies PCA/score-normalisation",
    "Ghidra decompilation of the 101.8 MiB lib timed out during auto-analysis (1500 s budget, shared lock); native evidence is capstone disassembly + DWARF/symbol analysis"
  ],
  "notes": "Package com.miui.face 1.37.4-A140026, APK sha256 7be477e2a28139d0ccd5c9c43e0f88d8afa8627cf4c8bd829af6bcde6bcee111, library app (0 components) publishing Binder 'miui.face.FaceService' via MiuiBioApp->MiuiFaceService.init->ServiceManager.addService. JNI lifecycle documented from DWARF+disasm of libjni_stfaceunlock_api.so: initLicense(st_face_init_license) -> createFaceAuth(st_auth_init(dir,cfg)->rc[0]) -> enroll(st_auth_enroll(img,cfg,&out); JNI returns *out, rc[0] gets call status) -> auth(st_auth_unlock(img,cfg,faceIds,count)->rc[0], faceIds is in/out) -> evaluate(st_auth_evaluate(in,out,fmt,w,h,orient,mode)). Thresholds read from .data: DEFAULT_OCULAR=9.0, FASTAUTH_HACKNESS=0.9, FASTAUTH_VERIFY=0.905, DEFAULT_LIVENESS=0.9, DEFAULT_VERIFY=0.905. 70.4 of the 101.8 MiB is 30 precompiled Adreno BCL kernel blobs; 46 *_ocl kernel names recovered (conv_filter3x3/5x5, conv_direct_transpose, bn_*, interp_*, subpixelUp/Down, argmax, pointsCurve). CAVEAT for main agent: an early extraction pass used VA as file offset (.data maps at VA-0x10000); models/extract_blobs.py now maps through section headers and evidence/blob_crypto_probe.txt was regenerated with corrected offsets. Deliverables: reports/miui_biometric/{report.md, findings.json (validated), sources/ (faceauth, faceunlock, faceunlock_app + index.md), native/ (ELF info, DWARF types, JNI/loader disassembly), models/ (8 blobs + manifest.json + extractor), ir/model_container.json, reimpl/ (pipeline.py, README.md, verify.txt), evidence/ (cmd.txt, hashes.json, blob_crypto_probe.txt, dex dumps, carve)}."
}