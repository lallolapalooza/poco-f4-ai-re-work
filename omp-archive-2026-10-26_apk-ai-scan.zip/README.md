# Session archive

Generated 2026-10-26T18:37:42.224Z from session `01a16b76-ae1f-7781-be28-2d1c2eb6ad21`.

## Layout

| Path | Contents |
| --- | --- |
| `manifest.json` | Index of everything below (counts, sizes, subagent list) |
| `session.jsonl` | The main session transcript, verbatim |
| `agents.json` | Live per-agent state captured while the session ran (model, system prompt, tools) |
| `jobs.json` | Background jobs: `completed` (recovered from transcripts) + `live` (running/recent at archive time) |
| `artifacts/` | Every file under the session artifact directory, verbatim |
| `viewer.html` | Standalone HTML viewer (all subagent sessions embedded) |

`artifacts/` is the important part: it holds each subagent's own
`<AgentId>.jsonl` transcript (recursively nested), the session's
`*.bash.log` / `*.eval.log` / `*.read.log` files with the **full, untruncated**
tool and background-job output, and `*.jsonl.tombstone` kill markers.

## Background jobs

147 completed jobs recovered from the transcripts (main + every subagent); full list in `jobs.json`. A live snapshot of running/recent jobs for Main, GapMEDIA_TFLITE, GapSECCENTER_SMS, GapMEDIA_PIPE, GapSECCORE_LUX, GapQCOM_EAI, GapEXTRAPHOTO_MACE, GapTIKTOK_DESC is also included. Per-job output lives in the owning transcript and in `artifacts/*.log`.

## Subagents (40)

- `ApkTooling` — 295 entries, 1265880 bytes
- `GapEXTRAPHOTO_MACE` — 627 entries, 1853679 bytes
- `GapMEDIA_PIPE` — 323 entries, 1058551 bytes
- `GapMEDIA_TFLITE` — 320 entries, 1410233 bytes
- `GapQCOM_EAI` — 518 entries, 1750245 bytes
- `GapSECCENTER_SMS` — 405 entries, 1301469 bytes
- `GapSECCORE_LUX` — 122 entries, 427420 bytes
- `GapTIKTOK_DESC` — 468 entries, 1613340 bytes
- `NativeTooling` — 316 entries, 1044445 bytes
- `PatchBIOMETRIC` — 421 entries, 1543310 bytes
- `PatchEXTRAPHOTO` — 589 entries, 2032432 bytes
- `PatchKWAIBULLDOG` — 441 entries, 1155746 bytes
- `PatchKWAILIVE` — 383 entries, 1187378 bytes
- `PatchKWAIVIDEO` — 410 entries, 1152861 bytes
- `PatchMEDIAEDITOR` — 527 entries, 1833221 bytes
- `PatchMTB` — 266 entries, 1020380 bytes
- `PatchPAYMENT` — 422 entries, 1192564 bytes
- `PatchQCOMVA` — 434 entries, 1354900 bytes
- `PatchREMOTE` — 537 entries, 1500582 bytes
- `PatchSECCENTER` — 367 entries, 1042638 bytes
- `PatchSECCOREADD` — 354 entries, 1162786 bytes
- `PatchSNAPCHAT` — 528 entries, 1517583 bytes
- `PatchTIKTOKMUSICALLY` — 271 entries, 796481 bytes
- `PatchTIKTOKTRILL` — 531 entries, 1582176 bytes
- `ResBIOMETRIC` — 464 entries, 1302245 bytes
- `ResEXTRAPHOTO` — 364 entries, 1423012 bytes
- `ResKWAI1` — 480 entries, 1241812 bytes
- `ResKWAI2` — 471 entries, 1367938 bytes
- `ResKWAI3` — 430 entries, 1463362 bytes
- `ResMEDIAEDITOR` — 504 entries, 1548106 bytes
- `ResMTB` — 308 entries, 738188 bytes
- `ResPAYMENT` — 546 entries, 1514522 bytes
- `ResQCOMVA` — 595 entries, 1770475 bytes
- `ResREMOTE` — 524 entries, 1661263 bytes
- `ResSECCENTER` — 494 entries, 1367784 bytes
- `ResSECCOREADD` — 392 entries, 1361389 bytes
- `ResSNAPCHAT` — 490 entries, 1555695 bytes
- `ResTIKTOK1` — 502 entries, 1717416 bytes
- `ResTIKTOK2` — 532 entries, 1275300 bytes
- `TfliteToJax` — 516 entries, 2190338 bytes

## Totals

266 files, 147325890 bytes.
